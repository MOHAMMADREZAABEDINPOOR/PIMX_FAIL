import { Startup, TechnicalBlueprint } from "./types";

export const SEED_STARTUPS: Startup[] = [
  {
    id: "wework",
    name: "WeWork",
    slogan: "Space as a service provider that promised to elevate the world's consciousness.",
    industry: "Real Estate Tech",
    yearFounded: 2010,
    yearFailed: 2023,
    fundingRaised: "$22.0B",
    primaryFailureReason: "Dysfunctional Unit Economics",
    detailedFailureReason: "Toxic leadership, uncurbed long-term lease liabilities, and astronomical burn rate masked as software scaling.",
    founders: ["Adam Neumann", "Rebekah Neumann", "Miguel McKelvey"],
    country: "United States",
    postMortem: "WeWork revolutionized modern coworking but suffered from an unsustainable asset-liability mismatch. It borrowed long (signing 15 to 20-year leases) and leased short (flexible monthly subscriptions). When economic shifts reduced occupancies, the locked-in real estate obligations remained. Combined with erratic administration and wasteful side-ventures (like WeGrow and WeLive), WeWork depleted billions in capital before filing for Chapter 11 bankruptcy reorganization in late 2023.",
    lessonsLearned: [
      "Avoid branding standard physical asset operations as high-margin software platforms in order to inflate valuations.",
      "Corporate governance must prevent single-founder supreme voting control.",
      "Ensure maturity matching between long-term lease obligations and transient customer lifetimes."
    ],
    metrics: {
      failureScore: 98,
      marketFitScore: 78,
      executionScore: 30,
      fundingRiskScore: 95,
      competitorRiskScore: 60
    }
  },
  {
    id: "theranos",
    name: "Theranos",
    slogan: "A biotech startup claiming to revolutionize blood testing with a single drop of blood.",
    industry: "Healthcare / Biotech",
    yearFounded: 2003,
    yearFailed: 2018,
    fundingRaised: "$1.4B",
    primaryFailureReason: "Technical Fraud & Regulatory",
    detailedFailureReason: "Fabricated hardware capabilities, secretive operating environment, and severe clinical regulatory violations.",
    founders: ["Elizabeth Holmes", "Sunny Balwani"],
    country: "United States",
    postMortem: "Theranos promised to perform dozens of clinical tests using automated micro-blood samples on its proprietary 'Edison' device. In reality, the technology never functioned safely or reliably. To mask failures, the company ran patient tests on commercial machines diluted with saline. Elizabeth Holmes orchestrated a highly structured culture of extreme compartmentalized secrecy, threatening whistleblowers and deceiving a star-studded board until investigative journalist John Carreyrou exposed the fraud.",
    lessonsLearned: [
      "No amount of visionary storytelling can substitute for peer-reviewed biological feedback.",
      "Corporate boards must contain subject-matter experts capable of validating technical metrics.",
      "Secrecy and aggressive compliance threats are leading indicators of systemic corporate fraud."
    ],
    metrics: {
      failureScore: 100,
      marketFitScore: 20,
      executionScore: 5,
      fundingRiskScore: 85,
      competitorRiskScore: 40
    }
  },
  {
    id: "ftx",
    name: "FTX",
    slogan: "One of the world's largest cryptocurrency exchanges representing trust and elite risk control.",
    industry: "Fintech / Crypto",
    yearFounded: 2019,
    yearFailed: 2022,
    fundingRaised: "$1.8B",
    primaryFailureReason: "Fraud & Governance collapse",
    detailedFailureReason: "Co-mingling customer deposits with speculative sister hedge fund Alameda Research via custom software backdoors.",
    founders: ["Sam Bankman-Fried", "Gary Wang"],
    country: "Bahamas",
    postMortem: "FTX collapsed spectacularly in November 2022. It was revealed that the exchange had surreptitiously funneled billions in customer deposits to bail out Alameda Research, its affiliate market-maker, which suffered enormous losses on leveraged tokens. An un-monitored software backdoor in the exchange system allowed Alameda to maintain an infinite negative balance. When Binance announced a complete sell-off of FTX's native FTT token, it triggered a classic run on the bank, exposing a multi-billion dollar liquidity deficit.",
    lessonsLearned: [
      "Absolute separations of client custody accounts and corporate trading operations are mandatory.",
      "Prevent self-referential token valuations where native collateral dictates overall exchange solvency.",
      "Auditing by un-established firms without oversight leaves key software backdoors unchecked."
    ],
    metrics: {
      failureScore: 99,
      marketFitScore: 90,
      executionScore: 15,
      fundingRiskScore: 99,
      competitorRiskScore: 55
    }
  },
  {
    id: "quibi",
    name: "Quibi",
    slogan: "Bite-sized high-production Hollywood-grade video content designed for mobile devices.",
    industry: "Entertainment / Media",
    yearFounded: 2018,
    yearFailed: 2020,
    fundingRaised: "$1.75B",
    primaryFailureReason: "No Market Need",
    detailedFailureReason: "Launching a product centered around mobile-commute consumption exactly as global pandemic lockdowns went live.",
    founders: ["Jeffrey Katzenberg", "Meg Whitman"],
    country: "United States",
    postMortem: "Quibi (Quick Bites) raised close to two billion dollars from big Hollywood studios to produce high-budget original shows split into 10-minute mobile-only chapters. However, the service launched in April 2020, just as the COVID-19 pandemic kept people working inside their homes next to large screens. Furthermore, the application blocked users from taking screenshots or sharing clips on social media, killing any organic discovery. It shut down and returned remains to investors after only 6 months.",
    lessonsLearned: [
      "Do not over-fund a startup before proving customer willingness to pay for a closed-garden delivery channel.",
      "Blocking natural user habits (e.g., sharing screenshots, making memes) is fatal for consumer growth.",
      "Remain flexible to alter deployment modes when major macro-conditions change."
    ],
    metrics: {
      failureScore: 90,
      marketFitScore: 35,
      executionScore: 40,
      fundingRiskScore: 70,
      competitorRiskScore: 80
    }
  },
  {
    id: "juicero",
    name: "Juicero",
    slogan: "Internet-connected premium juice squeezer that compressed customized organic packets.",
    industry: "Consumer Hardware / FoodTech",
    yearFounded: 2013,
    yearFailed: 2017,
    fundingRaised: "$120M",
    primaryFailureReason: "Over-engineering",
    detailedFailureReason: "Creating a highly precise $690 aluminum machine whose functions could be completed with human hands.",
    founders: ["Doug Evans"],
    country: "United States",
    postMortem: "Juicero designed a Wi-Fi-enabled home juicing machine sold for $690. The machine operated on custom QR-coded organic fruit and vegetable pouches shipped via subscription. A Bloomberg video exposed that users could squeeze the juice bags with their bare hands just as fast and effectively as the machine. Once the redundant engineering became public, sales dropped instantly, leading to an immediate operational shutdown.",
    lessonsLearned: [
      "Always seek simplicity; do not use expensive mechanical parts on a problem that human fingers can resolve.",
      "Hardware designs must defend their cost. High custom manufacturing costs must match genuine practical utility.",
      "Ensure software ties (like QR validation) represent safety, not margin-protection DRM."
    ],
    metrics: {
      failureScore: 85,
      marketFitScore: 25,
      executionScore: 60,
      fundingRiskScore: 75,
      competitorRiskScore: 40
    }
  },
  {
    id: "pebble",
    name: "Pebble",
    slogan: "Pioneering e-paper smartwatch that set early records on Kickstarter.",
    industry: "Consumer Tech / Wearables",
    yearFounded: 2012,
    yearFailed: 2016,
    fundingRaised: "$50M",
    primaryFailureReason: "Competitor Market Saturation",
    detailedFailureReason: "Squeezed out by tech giants (Apple and Samsung) entering the luxury wearables arena.",
    founders: ["Eric Migicovsky"],
    country: "Canada / US",
    postMortem: "Pebble established the modern smartwatch segment, raising over $40M across Kickstarter campaigns. Its low-power e-paper screen delivered long battery lives. However, when Apple entered with the Apple Watch and Pebble suffered from compounding hardware delays, the startup faced inventory glues. Under capital strain and lack of secondary financing, Pebble declined acquisitions before selling its assets and software IP to Fitbit.",
    lessonsLearned: [
      "Niche technical advantages are quickly replicated once massive ecosystem players move in.",
      "Manage hardware inventory levels conservatively; over-estimating demand causes fatal cash inventory holds.",
      "A software ecosystem (apps/developers) is more defensible than standalone hardware form factors."
    ],
    metrics: {
      failureScore: 65,
      marketFitScore: 75,
      executionScore: 70,
      fundingRiskScore: 80,
      competitorRiskScore: 95
    }
  },
  {
    id: "anki",
    name: "Anki",
    slogan: "AI-powered consumer robotics and toy developer animating home companions.",
    industry: "AI / Consumer Robotics",
    yearFounded: 2010,
    yearFailed: 2019,
    fundingRaised: "$200M",
    primaryFailureReason: "High R&D Burn Rate",
    detailedFailureReason: "High hardware engineering burn rates without secondary digital software monetization loops.",
    founders: ["Boris Sofman", "Mark Palatucci", "Hanns Tappeiner"],
    country: "United States",
    postMortem: "Anki created the Cozmo and Overdrive physical smartphone-controlled toy systems with embedded neural networks. While they sold hundreds of thousands of units, the ongoing maintenance, customer support, and massive engineering overhead exceeded retail revenue margins. The startup was working on a transformational hardware pipeline when a critical venture round collapsed, causing an abrupt shutdown during acquisition talks.",
    lessonsLearned: [
      "Physical goods require recurring high-margin digital software memberships to sustain continuous R&D burn.",
      "A single source of venture capital capitalization is a single point of failure.",
      "Keep development teams proportional to organic sales revenue rather than anticipated capital allocations."
    ],
    metrics: {
      failureScore: 78,
      marketFitScore: 70,
      executionScore: 85,
      fundingRiskScore: 90,
      competitorRiskScore: 65
    }
  },
  {
    id: "fast",
    name: "Fast",
    slogan: "One-click online checkout service designed to erase transactional friction.",
    industry: "Fintech / Payments",
    yearFounded: 2019,
    yearFailed: 2022,
    fundingRaised: "$120M",
    primaryFailureReason: "Astronomical Burn Rate",
    detailedFailureReason: "Unsustainable operational burn rate of $10M/month on less than $10K monthly revenue, coupled with aggressive self-marketing.",
    founders: ["Domm Holland", "Allison Barr Allen"],
    country: "United States",
    postMortem: "Fast aimed to build a seamless universal one-click checkout network across the internet. Backed by Stripe, the company scaled headcounts to over 450 employees globally and sponsored major events. However, merchant adoption lagged drastically. The company was generating less than $100K in annual transaction processing revenue while burning $10 million monthly. When venture capital conditions cooled and follow-on rounds fell through, the business was shuttered overnight.",
    lessonsLearned: [
      "No amount of visionary branding or high-profile sponsorships can compensate for missing product transaction volume.",
      "Venture funding should follow real distribution and usage metrics rather than hype-cycle headcounts.",
      "Track your company's actual ratio of capital-burned to recurring-revenue closely."
    ],
    metrics: {
      failureScore: 92,
      marketFitScore: 30,
      executionScore: 25,
      fundingRiskScore: 95,
      competitorRiskScore: 75
    }
  },
  {
    id: "katerra",
    name: "Katerra",
    slogan: "Technology-driven modular construction startup attempting to unify the end-to-end building lifecycles.",
    industry: "PropTech / Construction",
    yearFounded: 2015,
    yearFailed: 2021,
    fundingRaised: "$2.0B",
    primaryFailureReason: "Over-expansion & Supply chain",
    detailedFailureReason: "Over-aggressive programmatic acquisitions, manufacturing line bottlenecks, and highly disruptive construction cost estimation software failures.",
    founders: ["Michael Marks", "Fritz Wolff", "Jim Davidson"],
    country: "United States",
    postMortem: "Katerra promised to revolutionize construction by vertical integration—manufacturing customized structural modules in high-tech factories and shipping them to self-managed building sites. Fueled by SoftBank, Katerra acquired multiple engineering firms and design studios. However, regional construction practices are highly localized, causing factory alignment issues. Cost overruns, factory downtime, and accounting write-offs escalated before the company declared bankruptcy in 2021.",
    lessonsLearned: [
      "Construction is local, high-friction, and difficult to standardize within centralized factories.",
      "Growth-at-all-costs metrics fail in real-world infrastructure and manufacturing sectors.",
      "Rigid programmatic supply chains are too brittle to survive rapid changes in commodity building costs."
    ],
    metrics: {
      failureScore: 94,
      marketFitScore: 50,
      executionScore: 35,
      fundingRiskScore: 90,
      competitorRiskScore: 50
    }
  },
  {
    id: "jawbone",
    name: "Jawbone",
    slogan: "Wearable fitness tracker manufacturer and high-end bluetooth speaker visionary.",
    industry: "Consumer Electronics",
    yearFounded: 1999,
    yearFailed: 2017,
    fundingRaised: "$900M",
    primaryFailureReason: "Competitor Market Saturation",
    detailedFailureReason: "Over-funding, device waterproofing defects, and intense price pressure from Fitbit and Apple smartwatches.",
    founders: ["Hosain Rahman", "Alexander Asseily"],
    country: "United States",
    postMortem: "Jawbone (originally Aliph) created famous Bluetooth headsets and 'Jambox' speakers before pivoting entirely to 'UP' fitness trackers. Despite raising $900M, Jawbone suffered severe manufacturing delays and quality control defects (notably waterproofing issues with the UP band). Squeezed from the high end by the Apple Watch and the budget end by Fitbit and Xiaomi trackers, Jawbone's sales cratered, leading to debt defaults and liquidation in 2017.",
    lessonsLearned: [
      "Hardware startups must solve physical defect risks before investing heavily in global inventory marketing.",
      "Over-funding can prevent early financial discipline and lead to over-complicated product portfolios.",
      "Differentiate strongly on software features if your physical hardware format is easy to emulate."
    ],
    metrics: {
      failureScore: 88,
      marketFitScore: 65,
      executionScore: 45,
      fundingRiskScore: 80,
      competitorRiskScore: 90
    }
  },
  {
    id: "bird",
    name: "Bird",
    slogan: "Micro-mobility giant that flooded urban centers globally with electric dockless rental scooters.",
    industry: "Micro-mobility / Transit",
    yearFounded: 2017,
    yearFailed: 2023,
    fundingRaised: "$900M",
    primaryFailureReason: "Regulatory & Unit Economics",
    detailedFailureReason: "Severe local government regulatory backlashes, micro-asset depreciation (scooter lifespans), and operational tracking costs.",
    founders: ["Travis VanderZanden"],
    country: "United States",
    postMortem: "Bird launched dockless rental scooters to solve 'last-mile' transit. It grew faster than almost any startup and reached a $2.5B valuation. However, standard off-the-shelf consumer scooters broke in less than 30 days of outdoor rental use. City governments introduced caps, impounded vehicles, and demanded licensing. Despite designing custom durable models, operational costs and massive depreciation rates outran rental fees, leading to a NYSE de-listing and Chapter 11 filing in late 2023.",
    lessonsLearned: [
      "Physical micro-assets exposed to hostile environments require high longevity estimates to offset purchase costs.",
      "Bypassing systemic local regulatory frameworks creates massive, unpredictable global compliance liabilities.",
      "SaaS multiples do not apply to real-world hardware deployment models requiring manual operations."
    ],
    metrics: {
      failureScore: 95,
      marketFitScore: 70,
      executionScore: 50,
      fundingRiskScore: 85,
      competitorRiskScore: 80
    }
  },
  {
    id: "better-place",
    name: "Better Place",
    slogan: "Venture creating robotic electric battery-swapping networks for early EV fleets.",
    industry: "CleanTech / EV",
    yearFounded: 2007,
    yearFailed: 2013,
    fundingRaised: "$850M",
    primaryFailureReason: "Infrastructure Burn Rate",
    detailedFailureReason: "Under-estimating the astronomical deployment costs of robotic swapping bays and failure to align major automakers.",
    founders: ["Shai Agassi"],
    country: "Israel / US",
    postMortem: "Better Place sought to solve EV charging times by building swap-stations where robots replaced depleted batteries in under two minutes. However, each station cost $2.0M to build. Only Renault-Nissan designed vehicles to support the swapping hardware, while other major manufacturers standardized internal batteries with fast plug-in chargers. Lacking scale and user traction, the high-capital startup filed for bankruptcy after deploying only a fraction of its network.",
    lessonsLearned: [
      "Open hardware standards are mandatory if you expect to build infrastructure supporting third-party devices.",
      "High upfront infrastructure expenditures represent enormous risks compared to software iterations.",
      "Ensure consumer behaviors align cleanly; battery leasing was a concept users found confusing."
    ],
    metrics: {
      failureScore: 82,
      marketFitScore: 40,
      executionScore: 55,
      fundingRiskScore: 95,
      competitorRiskScore: 70
    }
  },
  {
    id: "hopin",
    name: "Hopin",
    slogan: "Virtual high-capacity corporate event browser platform that caught pandemic tailwinds.",
    industry: "SaaS / Virtual Events",
    yearFounded: 2019,
    yearFailed: 2023,
    fundingRaised: "$1.0B",
    primaryFailureReason: "Transient Market Need",
    detailedFailureReason: "Post-pandemic reopening of physical conferences, combined with aggressive acquisitions that dragged down core margins.",
    founders: ["Johnny Boufarhat"],
    country: "United Kingdom",
    postMortem: "Hopin built an exceptional virtual-conference platform that experienced dizzying growth in 2020 as lockdowns banned in-person gatherings. Valued at $7.7B in short order, Hopin went on a massive acquisition spree (buying StreamYard, Attendify, etc.). When global lock-downs ended, buyers immediately converted back to live physical events. Virtual ticket sales dwindled, forcing Hopin to sell its core events and hosting services to RingCentral for a small valuation, liquidating the rest.",
    lessonsLearned: [
      "Evaluate whether current exponential growth is standard SaaS expansion or a temporary macro-event product of lockdowns.",
      "Avoid acquiring complex legacy software products before stabilizing your primary customer retention cohorts.",
      "Ensure capital safety reserves remain loaded when building for highly cyclical or macro-dependant markets."
    ],
    metrics: {
      failureScore: 86,
      marketFitScore: 30,
      executionScore: 65,
      fundingRiskScore: 50,
      competitorRiskScore: 75
    }
  },
  {
    id: "scalefactor",
    name: "ScaleFactor",
    slogan: "Automated bookkeeping and financial analytics service powered by proprietary artificial intelligence.",
    industry: "Fintech / AI SaaS",
    yearFounded: 2014,
    yearFailed: 2020,
    fundingRaised: "$100M",
    primaryFailureReason: "Technical Fraud & Regulatory",
    detailedFailureReason: "Marketing human accountants in the backend as cutting-edge AI software, resulting in extreme transcription errors and customer churn.",
    founders: ["Kurt Rathmann"],
    country: "United States",
    postMortem: "ScaleFactor asserted that its AI algorithms could automatically compile, categorize, and execute accounting for small-to-medium businesses. In truth, the algorithms were highly inaccurate. To keep the product functional, the company hired armies of human accountants in-house and through external agencies to manually input ledger items. Customers complained about late tax filings, multi-million dollar calculation errors, and data backlogs, resulting in complete churn.",
    lessonsLearned: [
      "Never substitute mock AI software on problems requiring absolute technical precision (like audits and tax filings).",
      "Using human labor masquerading as automated software causes severe, un-scalable backend cost lines.",
      "Falsifying core software capability to venture investors is regulatory suicide."
    ],
    metrics: {
      failureScore: 91,
      marketFitScore: 40,
      executionScore: 10,
      fundingRiskScore: 75,
      competitorRiskScore: 50
    }
  },
  {
    id: "munchery",
    name: "Munchery",
    slogan: "Premium chef-designed gourmet meal delivery operation with direct-to-home delivery.",
    industry: "FoodTech / On-Demand",
    yearFounded: 2011,
    yearFailed: 2019,
    fundingRaised: "$120M",
    primaryFailureReason: "Dysfunctional Unit Economics",
    detailedFailureReason: "Subsidized home-cooked meals, extreme food waste in central industrial kitchens, and high shipping costs.",
    founders: ["Tri Tran", "Conrad Chu"],
    country: "United States",
    postMortem: "Munchery cooked chef-grade dishes in mega-kitchens and chilled them so customers could run home and heat them up. To fight Blue Apron and UberEats, Munchery highly subsidized meal prices, and threw out mountains of un-ordered fresh meals every night. Customer acquisition costs were high, but retention was dismal once promotions stopped. Munchery exhausted its runway, suddenly closing doors in 2019, leaving subscribers with un-redeemed balances.",
    lessonsLearned: [
      "Perishable inventory margins cannot sustain high customer acquisition subsidy models.",
      "On-demand food logistics requires density; do not expand geographically until regional units are highly profitable.",
      "Accurate demand-prediction software models must guide physical production limits to avoid physical waste."
    ],
    metrics: {
      failureScore: 89,
      marketFitScore: 55,
      executionScore: 40,
      fundingRiskScore: 80,
      competitorRiskScore: 85
    }
  },
  {
    id: "solyndra",
    name: "Solyndra",
    slogan: "Cylindrical thin-film copper-indium-gallium-selenide solar panel manufacturer.",
    industry: "CleanTech / Solar",
    yearFounded: 2005,
    yearFailed: 2011,
    fundingRaised: "$535M",
    primaryFailureReason: "Competitor Market Saturation",
    detailedFailureReason: "Astronomical silicon solar price drops driven by foreign manufacturers, rendering Solyndra's custom chemical model obsolete.",
    founders: ["Chris Gronet"],
    country: "United States",
    postMortem: "Solyndra designed unique cylindrical solar panels that didn't require tracking motors. Backed by a famous $535M federal loan guarantee, it set up massive automated factories. However, right as factories opened, the global market price of standard silicon (used in standard flat panels) crashed by over 80% due to overseas manufacturing subsidies. Solyndra's customized, silicon-free panels became un-competitively expensive to manufacture, forcing a rapid, controversial bankruptcy.",
    lessonsLearned: [
      "A software or hardware process centering on a specific raw commodity (like silicon) is exposed to major market fluctuations.",
      "Avoid capital-intensive factory builds before verifying alternative standard manufacturing pricing trajectories.",
      "Public-financed debt structures can carry massive political and operational restrictions."
    ],
    metrics: {
      failureScore: 87,
      marketFitScore: 25,
      executionScore: 60,
      fundingRiskScore: 95,
      competitorRiskScore: 98
    }
  },
  {
    id: "segway",
    name: "Segway",
    slogan: "Self-balancing two-wheeled electric personal transporters designed to revolutionize transport.",
    industry: "Hardware / Mobility",
    yearFounded: 1999,
    yearFailed: 2020,
    fundingRaised: "$160M",
    primaryFailureReason: "No Market Need",
    detailedFailureReason: "High consumer price, lack of roadside legal clarity, and mismatch between hype and practical utility.",
    founders: ["Dean Kamen"],
    country: "United States",
    postMortem: "Steve Jobs and Jeff Bezos claimed Segway would be 'bigger than the PC' and reshape city architecture. However, at launch, the device cost $5,000, making it inaccessible to average commuters. Legally, cities banned them from sidewalks while riders felt unsafe on busy streets. It found minimal niche traction beyond mall security guards and tourist operations, before getting bought and discontinued in 2020.",
    lessonsLearned: [
      "Over-hyping a product before validating consumer cost expectations can cause fatal marketing backlashes.",
      "Do not build a transport medium without ensuring corresponding city legal permissions exist.",
      "Design for the general user's daily habits rather than forcing users to adopt unfamiliar public paradigms."
    ],
    metrics: {
      failureScore: 74,
      marketFitScore: 20,
      executionScore: 70,
      fundingRiskScore: 70,
      competitorRiskScore: 40
    }
  },
  {
    id: "cana-one",
    name: "Cana One",
    slogan: "Molecular countertop beverage printer that synthesized sodas, beers, and coffees from cartridges.",
    industry: "Consumer Electronics",
    yearFounded: 2021,
    yearFailed: 2023,
    fundingRaised: "$30M",
    primaryFailureReason: "High R&D Burn Rate",
    detailedFailureReason: "High complex mechanical development costs, combined with sudden post-interest rate funding freeze.",
    founders: ["Matt Mahar"],
    country: "United States",
    postMortem: "Cana aimed to build 'the Netflix of beverages'—a beautiful molecular counter machine that could print juice, soft drinks, wine, or cold-brew coffee using a cartridge of pure flavors and compounds. It designed a working prototype and locked in pre-orders. However, building a kitchen appliance that handles pressurized liquids, temperature control, and food security requires massive capital. When macroeconomic rates jumped in 2023, funding dried up, forcing a shutdown before shipping.",
    lessonsLearned: [
      "Countertop consumer hardware is incredibly capital-intensive and hard to validate with digital mock-ups.",
      "Secure production supply lines and tooling capital before launching long-term consumer pre-order campaigns.",
      "Always have a backup operational preservation plan if your model relies on continuous venture rounds."
    ],
    metrics: {
      failureScore: 84,
      marketFitScore: 50,
      executionScore: 65,
      fundingRiskScore: 98,
      competitorRiskScore: 35
    }
  },
  {
    id: "beepi",
    name: "Beepi",
    slogan: "Online peer-to-peer used car marketplace that handled inspections and deliveries.",
    industry: "E-Commerce / Auto",
    yearFounded: 2013,
    yearFailed: 2017,
    fundingRaised: "$150M",
    primaryFailureReason: "Over-engineering & Management",
    detailedFailureReason: "Extreme executive cash spend, over-staffing, and $10,000 office sofa budgets, leading to swift cash drain.",
    founders: ["Ale Resnik", "Omer Savir"],
    country: "United States",
    postMortem: "Beepi sought to clear out used car dealers by building a high-trust peer-to-peer bidding site. It offered a full 240-point manual inspection and guaranteed a buyer. However, management operated with reckless capital burn. They paid massive salaries, rented luxurious corporate suites, and spent huge sums on unnecessary assets. When a $50M Chinese investor round collapsed, the lack of financial controls left Beepi with zero reserves, resulting in immediate liquidation.",
    lessonsLearned: [
      "No matter how high your transactional volume, weak cash management controls will bankrupt a business.",
      "Keep operational overhead minimal and headcounts lean until clear market profitability is reached.",
      "Venture rounds must never be treated as guaranteed capital until bank transfers clear."
    ],
    metrics: {
      failureScore: 96,
      marketFitScore: 60,
      executionScore: 15,
      fundingRiskScore: 90,
      competitorRiskScore: 60
    }
  },
  {
    id: "casper",
    name: "Casper",
    slogan: "Direct-to-consumer mattress company that sold high-density foam mattresses in boxes.",
    industry: "E-Commerce / Consumables",
    yearFounded: 2014,
    yearFailed: 2021,
    fundingRaised: "$340M",
    primaryFailureReason: "Dysfunctional Unit Economics",
    detailedFailureReason: "High shipping returns, outrageous advertising costs, and extreme clone-brand copycats.",
    founders: ["Philip Krim", "Neil Parikh", "Luke Sherwin"],
    country: "United States",
    postMortem: "Casper revolutionized buying mattresses online with its funny cartoon ads and simple box delivery. Its initial growth was outstanding. However, it turned out that customers only buy mattresses once every ten years. To acquire new sales, Casper was spending up to $300 in advertising per user. Worse, hundreds of copycats (Purple, Nectar, Tuft & Needle) copied the physical direct model, eroding margins. Casper suffered major losses, went public at a distressed valuation, and quickly sold out to private equity.",
    lessonsLearned: [
      "A product with a long replacement cycle (10 years) cannot support high recurring customer acquisition budgets.",
      "Physical direct-to-consumer models are easily duplicated unless protected by patented technical components.",
      "A mattress company is primarily a manufacturing logistics business, not a high-multiple tech platform."
    ],
    metrics: {
      failureScore: 79,
      marketFitScore: 80,
      executionScore: 50,
      fundingRiskScore: 70,
      competitorRiskScore: 98
    }
  }
];

export const TECHNICAL_BLUEPRINTS: TechnicalBlueprint[] = [
  {
    id: "architecture",
    title: "System Architecture",
    category: "Edge Infrastructure",
    description: "Multi-layered global request flow, highlighting Edge rendering, API router proxies, local caches, and the decoupled storage engine optimized for Cloudflare Pages and Workers.",
    icon: "Network",
    codeLanguage: "text",
    code: `┌────────────────────────────────────────────────────────────────────────┐
│                        STARTUP GRAVEYARD - EDGE SAAS                   │
│                               SYSTEM ARCHITECTURE                      │
└────────────────────────────────────────────────────────────────────────┘

 [ Client Browser ]
        │
        ▼ (HTTPS / HTTP/3 via Cloudflare CDN)
 ┌──────────────────────────────────────────────────────────────────────┐
 │                     CLOUDFLARE CDN / GLOBAL ANYCAST                  │
 │      * Edge TLS 1.3 Termination    * Automatic WebP Rendering        │
 │      * WAF (DDoS Mitigation)       * Global Geo-Routing & Latency    │
 └──────────────────────────────────────────────────────────────────────┘
        │
        ├────────────────────────────────────┐
        ▼ (NextJS Page View / Static Assets)  ▼ (Edge API Handler)
 ┌────────────────────────────────────────┐ ┌──────────────────────────┐
 │           CLOUDFLARE PAGES             │ │    CLOUDFLARE WORKERS    │
 │   - Pre-rendered HTML Pages            │ │    - Hono Framework      │
 │   - Localized Routes                   │ │    - Edge Middleware     │
 │   - Static Client JS Bundles           │ │    - Auth.js Edge checks │
 └────────────────────────────────────────┘ └──────────────────────────┘
                                                 │       │       │
      ┌──────────────────────────────────────────┘       │       └──────────────────────────────────┐
      ▼ (D1 Driver Calls)                                ▼ (Storage Streams)                        ▼ (Secure API Proxy)
 ┌────────────────────────────────────────┐ ┌──────────────────────────────────────────┐ ┌────────────────────────────────┐
 │        CLOUDFLARE D1 DATABASE          │ │          CLOUDFLARE R2 BUCKET            │ │         GEMINI AI API          │
 │   - Globally Distributed SQLite        │ │   - S3-Compatible Asset Storage          │ │   - Server-Side SDK Call       │
 │   - Real-time Read replication         │ │   - Post-Mortem PDFs, Startup Images     │ │   - Multi-modal Text/JSON prompt   │
 │   - Edge-Optimized Read Latency (<10ms)│ │   - Zero Egress Fees / Globally Cached   │ │   - Secret Key Kept In Worker  │
 └────────────────────────────────────────┘ └──────────────────────────────────────────┘ └────────────────────────────────┘
                                                 ▲
                                                 │ (Audit Logs)
                                            ┌──────────────────────────┐
                                            │      ACTIVITY ENGINE     │
                                            │ - KV Log Persistence     │
                                            │ - Worker Cron Cleaners   │
                                            └──────────────────────────┘`
  },
  {
    id: "folder-structure",
    title: "Folder Structure",
    category: "Codebase Organization",
    description: "Production structure for a Turborepo-driven monorepo or standard hybrid structure encapsulating Cloudflare Pages, Workers, Next.js, and Drizzle config.",
    icon: "FolderGit2",
    codeLanguage: "text",
    code: `startup-graveyard/
├── .github/                  # CI/CD Workflows for Cloudflare Wrangler deploys
├── assets/                   # Non-web graphics and asset blueprints
├── config/                   # Shared configurations (Eslint, Prettier, Typescript)
├── drizzle/                  # Auto-generated SQL migration files (D1 dialect)
│   ├── _meta/                # Drizzle migration history
│   └── 0000_initial_db.sql   # Consolidated SQL tables ddl
├── src/                      # Monolithic Edge / Next.js Hybrid directory
│   ├── app/                  # Next.js 15 App Router directory
│   │   ├── [locale]/         # next-intl Localized Route groups (/en, /fa, /de)
│   │   │   ├── layout.tsx    # Global template with provider bindings
│   │   │   ├── page.tsx      # Landing page / Startups catalog hub
│   │   │   ├── startups/     # Directory for individual startup details
│   │   │   │   └── [slug]/
│   │   │   └── admin/        # Admin Moderation portal
│   │   │       └── page.tsx
│   │   ├── api/              # Secondary API integrations via Route Handlers
│   │   └── middleware.ts     # Locale-detection and dynamic routing handler
│   ├── components/           # Atomic Design UI architecture
│   │   ├── ui/               # Base Tailwind elements (buttons, inputs)
│   │   ├── charts/           # SVG failure breakdowns
│   │   └── layout/           # Sidebar, Navigation and Theme Toggle
│   ├── db/                   # Database ORM connection
│   │   ├── schema.ts         # Complete Drizzle tables and relations definitions
│   │   └── index.ts          # Edge SQL connection bootloader
│   └── types/                # Typescript common enums and structures
├── workers/                  # Decoupled high-performance Cloudflare Worker logic
│   ├── api-gateway/          # Hono gateway handling dynamic AI queries and KV sessions
│   │   ├── src/index.ts
│   │   └── wrangler.toml     # Worker service bindings configure file
│   └── cron-aggregator/      # Daily stats processor for trending graveyard items
├── wrangler.toml             # Database D1 binding file
├── package.json              # Workspace script orchestration
└── tsconfig.json             # Root strict Typescript specification`
  },
  {
    id: "drizzle-schema",
    title: "Drizzle Schema",
    category: "Database Design",
    description: "Type-safe Drizzle ORM schema defining all required tables, UUID identifiers, foreign key relations, and indexes optimized for SQLite / Cloudflare D1.",
    icon: "FileCode",
    codeLanguage: "typescript",
    code: `import { sqliteTable, text, integer, uniqueIndex, index } from "drizzle-orm/sqlite-core";
import { relations } from "drizzle-orm";

// 1. Roles Definition
export const roles = sqliteTable("roles", {
  id: text("id").primaryKey(), // 'guest', 'user', 'premium', 'moderator', 'admin', 'super_admin'
  name: text("name").notNull(),
  createdAt: text("created_at").notNull(),
  updatedAt: text("updated_at").notNull()
});

// 2. Users Table
export const users = sqliteTable("users", {
  id: text("id").primaryKey(), // UUID v4
  email: text("email").notNull().unique(),
  roleId: text("role_id").notNull().references(() => roles.id),
  createdAt: text("created_at").notNull(),
  updatedAt: text("updated_at").notNull(),
  createdBy: text("created_by"),
  updatedBy: text("updated_by")
}, (table) => ({
  emailIdx: uniqueIndex("users_email_idx").on(table.email)
}));

// 3. User Profiles
export const userProfiles = sqliteTable("user_profiles", {
  id: text("id").primaryKey(),
  userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  fullName: text("full_name"),
  avatarUrl: text("avatar_url"),
  bio: text("bio"),
  preferredLang: text("preferred_lang").default("en"),
  createdAt: text("created_at").notNull(),
  updatedAt: text("updated_at").notNull()
});

// 4. Startups Table
export const startups = sqliteTable("startups", {
  id: text("id").primaryKey(), // UUID or clean slug (e.g., 'wework')
  slug: text("slug").notNull().unique(),
  yearFounded: integer("year_founded").notNull(),
  yearFailed: integer("year_failed").notNull(),
  fundingRaised: text("funding_raised").notNull(),
  countryCode: text("country_code").notNull(),
  isApproved: integer("is_approved").default(0), // 0 or 1
  failureScore: integer("failure_score").default(50),
  marketFitScore: integer("market_fit_score").default(50),
  executionScore: integer("execution_score").default(50),
  fundingRiskScore: integer("funding_risk_score").default(50),
  competitorRiskScore: integer("competitor_risk_score").default(50),
  createdAt: text("created_at").notNull(),
  updatedAt: text("updated_at").notNull(),
  createdBy: text("created_by"),
  updatedBy: text("updated_by")
}, (table) => ({
  slugIdx: uniqueIndex("startups_slug_idx").on(table.slug),
  approvedIdx: index("startups_approved_idx").on(table.isApproved)
}));

// 5. Startup Translations (All translations reside here)
export const startupTranslations = sqliteTable("startup_translations", {
  id: text("id").primaryKey(),
  startupId: text("startup_id").notNull().references(() => startups.id, { onDelete: "cascade" }),
  language: text("language").notNull(), // 'en', 'fa', 'de', 'zh' etc.
  name: text("name").notNull(),
  slogan: text("slogan").notNull(),
  detailedFailureReason: text("detailed_failure_reason").notNull(),
  postMortem: text("post_mortem").notNull(),
  createdAt: text("created_at").notNull(),
  updatedAt: text("updated_at").notNull()
}, (table) => ({
  langIdx: index("translation_lang_idx").on(table.startupId, table.language)
}));

// 6. Lessons Learned Table
export const lessonsLearned = sqliteTable("lessons_learned", {
  id: text("id").primaryKey(),
  startupId: text("startup_id").notNull().references(() => startups.id, { onDelete: "cascade" }),
  createdAt: text("created_at").notNull(),
  updatedAt: text("updated_at").notNull()
});

// 7. Lesson Translations
export const lessonTranslations = sqliteTable("lesson_translations", {
  id: text("id").primaryKey(),
  lessonId: text("lesson_id").notNull().references(() => lessonsLearned.id, { onDelete: "cascade" }),
  language: text("language").notNull(),
  description: text("description").notNull(),
  createdAt: text("created_at").notNull()
});

// 8. Bookmarks
export const bookmarks = sqliteTable("bookmarks", {
  id: text("id").primaryKey(),
  userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  startupId: text("startup_id").notNull().references(() => startups.id, { onDelete: "cascade" }),
  createdAt: text("created_at").notNull()
}, (table) => ({
  userStartupIdx: uniqueIndex("bookmark_user_startup_idx").on(table.userId, table.startupId)
}));

// 9. Comments
export const comments = sqliteTable("comments", {
  id: text("id").primaryKey(),
  userId: text("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  startupId: text("startup_id").notNull().references(() => startups.id, { onDelete: "cascade" }),
  content: text("content").notNull(),
  isFlagged: integer("is_flagged").default(0),
  createdAt: text("created_at").notNull(),
  updatedAt: text("updated_at").notNull()
});

// Relationships Modeling
export const startupsRelations = relations(startups, ({ many }) => ({
  translations: many(startupTranslations),
  lessons: many(lessonsLearned),
  bookmarks: many(bookmarks),
  comments: many(comments)
}));

export const startupTranslationsRelations = relations(startupTranslations, ({ one }) => ({
  startup: one(startups, {
    fields: [startupTranslations.startupId],
    references: [startups.id]
  })
}));`
  },
  {
    id: "sql-schema",
    title: "SQL Schema",
    category: "Database Design",
    description: "Equivalent SQLite / D1 DDL containing absolute integrity rules, cascade deletions, default flags, and secondary indexes optimized for global scale query caching.",
    icon: "DatabaseBackup",
    codeLanguage: "sql",
    code: `-- Setup System Roles
CREATE TABLE IF NOT EXISTS roles (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

-- Seed System default roles
INSERT OR IGNORE INTO roles (id, name, created_at, updated_at) VALUES 
('guest', 'Guest', '2026-06-19', '2026-06-19'),
('user', 'User', '2026-06-19', '2026-06-19'),
('premium', 'Premium Member', '2026-06-19', '2026-06-19'),
('moderator', 'Content Moderator', '2026-06-19', '2026-06-19'),
('admin', 'Site Administrator', '2026-06-19', '2026-06-19'),
('super_admin', 'SaaS Creator', '2026-06-19', '2026-06-19');

-- Users Core Table
CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  email TEXT NOT NULL,
  role_id TEXT NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  created_by TEXT,
  updated_by TEXT,
  FOREIGN KEY (role_id) REFERENCES roles(id)
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_users_email ON users(email);

-- User Profile Container
CREATE TABLE IF NOT EXISTS user_profiles (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  full_name TEXT,
  avatar_url TEXT,
  bio TEXT,
  preferred_lang TEXT DEFAULT 'en',
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Startup Master Entity
CREATE TABLE IF NOT EXISTS startups (
  id TEXT PRIMARY KEY,
  slug TEXT NOT NULL UNIQUE,
  year_founded INTEGER NOT NULL,
  year_failed INTEGER NOT NULL,
  funding_raised TEXT NOT NULL,
  country_code TEXT NOT NULL,
  is_approved INTEGER DEFAULT 0,
  failure_score INTEGER DEFAULT 50,
  market_fit_score INTEGER DEFAULT 50,
  execution_score INTEGER DEFAULT 50,
  funding_risk_score INTEGER DEFAULT 50,
  competitor_risk_score INTEGER DEFAULT 50,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  created_by TEXT,
  updated_by TEXT
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_startups_slug ON startups(slug);
CREATE INDEX IF NOT EXISTS idx_startups_approved ON startups(is_approved);

-- Direct Translations for Startups
CREATE TABLE IF NOT EXISTS startup_translations (
  id TEXT PRIMARY KEY,
  startup_id TEXT NOT NULL,
  language TEXT NOT NULL,
  name TEXT NOT NULL,
  slogan TEXT NOT NULL,
  detailed_failure_reason TEXT NOT NULL,
  post_mortem TEXT NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  FOREIGN KEY (startup_id) REFERENCES startups(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_translations_lookup ON startup_translations (startup_id, language);

-- Subscriptions Table for Revenue Track
CREATE TABLE IF NOT EXISTS subscriptions (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  stripe_customer_id TEXT UNIQUE,
  stripe_subscription_id TEXT UNIQUE,
  status TEXT NOT NULL, -- 'active', 'canceled', 'incomplete'
  plan_type TEXT NOT NULL, -- 'lifetime', 'monthly', 'annual'
  ends_at TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);`
  },
  {
    id: "migration-files",
    title: "Migration Files",
    category: "Codebase Organization",
    description: "Sample meta files representing the exact folder output and syntax produced by drizzle-kit generate:sqlite command configurations.",
    icon: "FolderSync",
    codeLanguage: "sql",
    code: `-- Migration: 0000_initial_db.sql
-- Created At: 2026-06-19 00:00:00
-- Dialect: SQLite (Cloudflare D1 Dialect)

--> Statement 1
CREATE TABLE \`roles\` (
  \`id\` text PRIMARY KEY NOT NULL,
  \`name\` text NOT NULL,
  \`created_at\` text NOT NULL,
  \`updated_at\` text NOT NULL
);

--> Statement 2
CREATE TABLE \`users\` (
  \`id\` text PRIMARY KEY NOT NULL,
  \`email\` text NOT NULL,
  \`role_id\` text NOT NULL,
  \`created_at\` text NOT NULL,
  \`updated_at\` text NOT NULL,
  \`created_by\` text,
  \`updated_by\` text,
  FOREIGN KEY (\`role_id\`) REFERENCES \`roles\`(\`id\`) ON UPDATE no action ON DELETE no action
);

--> Statement 3
CREATE CREATE INDEX \`users_email_idx\` ON \`users\` (\`email\`);

--> Statement 4
CREATE TABLE \`startup_tags\` (
  \`id\` text PRIMARY KEY NOT NULL,
  \`startup_id\` text NOT NULL,
  \`tag_id\` text NOT NULL,
  \`created_at\` text NOT NULL,
  FOREIGN KEY (\`startup_id\`) REFERENCES \`startups\`(\`id\`) ON UPDATE cascade ON DELETE cascade
);

--> Meta Schema Control Log
-- {"version":"6","dialect":"sqlite","out":"./drizzle","id":"bdf5fca0-f472-46be-9e0a-0b22a8dc4fc8"}`
  },
  {
    id: "api-design",
    title: "API Design",
    category: "Edge API",
    description: "Complete Hono router routes setup in Cloudflare Workers representing REST schemas, request query validators, and responsive JSON outputs.",
    icon: "Cpu",
    codeLanguage: "typescript",
    code: `import { Hono } from "hono";
import { databaseBinding } from "./middleware/drizzle";
import { z } from "zod";
import { zValidator } from "@hono/zod-validator";

const app = new Hono<{ Bindings: Env }>();

// GET /api/startups - Query with limit, locale and industry filters
app.get("/api/startups", async (c) => {
  const { limit = "10", offset = "0", industry, locale = "en" } = c.req.query();
  const db = c.get("db");

  const results = await db.query.startups.findMany({
    where: (startups, { eq, and }) => {
      const filters = [eq(startups.isApproved, 1)];
      if (industry) filters.push(eq(startups.countryCode, industry));
      return and(...filters);
    },
    with: {
      translations: {
        where: (t, { eq }) => eq(t.language, locale)
      }
    },
    limit: parseInt(limit),
    offset: parseInt(offset)
  });

  return c.json({
    success: true,
    data: results,
    paging: { limit, offset }
  });
});

// POST /api/ai/analyze - Generates custom breakdown with validator protection
const analyzeSchema = z.object({
  name: z.string().min(2, "Name must possess at least 2 characters"),
  description: z.string().min(10, "Minimum 10 characters required"),
  industry: z.string().optional(),
  failureReasons: z.string().optional()
});

app.post("/api/ai/analyze", zValidator("json", analyzeSchema), async (c) => {
  const body = c.req.valid("json");
  const env = c.env;

  // Initialize Gemini API securely from Node/Worker process
  const response = await fetch("https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=" + env.GEMINI_API_KEY, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      contents: [{ parts: [{ text: \`Review failure profile of \${body.name} in industry \${body.industry || "General Tech"}: \${body.description}\` }] }],
      generationConfig: { responseMimeType: "application/json" }
    })
  });

  const parsed = await response.json();
  return c.json({
    success: true,
    diagnostic: parsed
  });
});`
  },
  {
    id: "cloudflare-config",
    title: "Cloudflare Config",
    category: "DevOps / Infrastructure",
    description: "Production configuration file (wrangler.toml) to bind and provision Cloudflare D1 SQL database variables, R2 objects, KV systems, and caching rules.",
    icon: "Settings",
    codeLanguage: "toml",
    code: `# wrangler.toml
name = "startup-graveyard"
main = "src/server.ts"
compatibility_date = "2026-06-19"
node_compat = true

[vars]
ENVIRONMENT = "production"
APP_URL = "https://startupgraveyard.com"
SESSION_SECRET = "067623a6f44d852a36d2eb12ef2cdef283df8ef309dfcecf"

# Bindings to Distributed Cloudflare D1 SQLite DB
[[d1_databases]]
binding = "DB"
database_name = "startup_graveyard_db"
database_id = "f0b4b223-92f5-46f5-93df-5cc90b8db5e2"
migrations_dir = "./drizzle"

# Bindings to Distributed Cloudflare R2 S3 storage
[[r2_buckets]]
binding = "BUCKET"
bucket_name = "startup-graveyard-assets"

# KV Cache store for rapid localization strings & rate limits
[[kv_namespaces]]
binding = "CACHE_STORE"
id = "70500db620ec422fbcdce05a5aeee5f6"

[env.production.routes]
pattern = "api.startupgraveyard.com/*"
zone_name = "startupgraveyard.com"`
  },
  {
    id: "deployment-instructions",
    title: "Deployment Guide",
    category: "DevOps / Infrastructure",
    description: "The complete setup commands to compile typescript schema states, migrate Cloudflare D1 tables globally, and launch applications with Wrangler CLI.",
    icon: "Terminal",
    codeLanguage: "bash",
    code: `# 1. Install Workspace dependencies
npm install -g wrangler
npm install

# 2. Authenticate locally with Cloudflare development CLI
wrangler login

# 3. Create real D1 database instance on Edge
wrangler d1 create startup_graveyard_db
# Copy the printed database_id and paste to wrangler.toml block!

# 4. Compile and bundle database tables via Drizzle Kit
npx drizzle-kit generate

# 5. Apply database migration tables directly to local SQLite for tests
npx drizzle-kit push:sqlite

# 6. Apply database schemas directly to cloud Cloudflare D1 instance
wrangler d1 migrations apply DB --remote

# 7. Provision Cloudflare R2 Bucket for Startup visual storage
wrangler r2 bucket create startup-graveyard-assets

# 8. Deploy Worker API router and Static Pages edge framework
npm run build
wrangler deploy`
  },
  {
    id: "mvp-roadmap",
    title: "MVP Roadmap",
    category: "Product Management",
    description: "Product growth roadmap across critical development, optimization, payment validation, and global scale launch phases.",
    icon: "CalendarRange",
    codeLanguage: "text",
    code: `┌────────────────────────────────────────────────────────────────────────┐
│                         STARTUP GRAVEYARD - MVP ROADMAP               │
└────────────────────────────────────────────────────────────────────────┘

 [ PHASE 1: CORE ENGINE -- DAYS 1-7 ]
   ├─ Build Drizzle SQLite schemas and execute migrations to Cloudflare D1.
   ├─ Complete WeWork, Theranos and FTX high-fidelity dataset seed operations.
   ├─ Connect Express and Hono edge structures to serve startup catalogs.
   └─ Configure next-intl localization paths matching user geographic origins.

 [ PHASE 2: AI AUTOPSY SERVICE -- DAYS 8-12 ]
   ├─ Wire server-side Google GenAI SDK powered by gemini-3.5-flash.
   ├─ Connect diagnostic JSON validation systems to capture failure score categories.
   ├─ Build custom localized responsive gauges using light SVG structures.
   └─ Implement client-side localStorage bookmarks & custom failure folders.

 [ PHASE 3: PAYMENT INTEGRATION -- DAYS 13-17 ]
   ├─ Set up Stripe Checkout bindings inside Cloudflare Workers.
    ├─ Configure immediate client notifications upon subscription validation hooks.
    └─ Secure Moderator Dashboard interfaces behind Admin RBAC checks.

 [ PHASE 4: GLOBAL EDGE PRE-OPTIMIZATION -- DAYS 18-21 ]
    ├─ Apply Cache-Control headers to compress network packet transfer sizes.
    ├─ Establish robots.txt, dynamic hreflangs, and dynamic JSON-LD metadata cards.
    └─ Deploy globally via wrangler deploy to final cloud-native destinations.`
  }
];

export const TRANSLATIONS: Record<string, Record<string, string>> = {
  en: {
    title: "PIMXFAIL",
    subtitle: "The world's largest database of failed startups, post-mortems, and lessons learned.",
    tagline: "Where failed ideas go to live forever. Learn from the dead to build the future.",
    searchPlaceholder: "Search by startup, founder, or keyword...",
    filterAll: "All Industries",
    filterReason: "All Failure Reasons",
    addBtn: "Submit Startup Autopsy",
    analyzing: "Analyzing failure vector...",
    analyzeBtn: "AI Failure Analysis Console",
    blueprintTitle: "Technical Blueprint Hub",
    blueprintSubtitle: "Explore copyable, production-ready Edge configurations for this app",
    statsTitle: "Autopsy Statistics",
    failureByReason: "Failure Breakdown by Root Cause",
    averageLifespan: "Survival Timeline Breakdown",
    submitSuccess: "Post-Mortem submitted successfully! Awaiting moderation.",
    failureScore: "Failure Score",
    marketFit: "Market Fit",
    execution: "Execution",
    fundingRisk: "Funding Risk",
    competitorRisk: "Competitor Saturation",
    lessonsTitle: "Post-Mortem Lessons learned",
    aboutAuthor: "Elite CTO Specifications Node",
    bookmarkTab: "My Bookmarked Autopsies",
    noBookmarks: "You haven't bookmarked any autopsies yet.",
    activeUsers: "Active Analysts",
    gravesCount: "Startup Autopsies",
    reasonsCount: "Identified Failure Vectors",
    learnHub: "Technical specifications guidelines",
    promptName: "Startup Nominee",
    promptDesc: "Autopsy Description & Operational Friction",
    promptIndustry: "Commercial Industry Vertical",
    promptReason: "Primary Catalyst of Collapse",
    promptSubmit: "Generate Autopsy Diagnosis",
    diagnosticTitle: "Autopsy Diagnostic Report",
    mistakesTitle: "Primary Systemic Mistakes",
    recoveryAction: "Autopsy Action Counterfactual",
    graveyardDb: "Graveyard DB",
    blueprintTabsHeader: "Blueprint Sections",
    copySpecCode: "Copy Spec Code",
    copiedSection: "Copied Section!",
    instantDeath: "Instant Death",
    pivotCrisis: "Pivot Crisis",
    scalingTrap: "Scaling Trap",
    legacyFade: "Legacy Fade",
    range: "range",
    medianSurvivalAlert: "Median Survival rate: 4.7 Years before cash reserves collapse. 82% of tracked failures in our database raised a secondary Series A round before experiencing capital exhaustion due to misaligned scaling triggers.",
    breakdownNoMarket: "No Market Need (Quibi)",
    breakdownEconomics: "Dysfunctional Economics (WeWork)",
    breakdownEngineering: "Over-engineering (Juicero)",
    breakdownFraud: "Fraud & Misgovernance (FTX, Theranos)",
    breakdownSaturation: "Competitor Saturation (Pebble)",
    language: "English",

    hubBadge: "💀 Global Autopsy Database Hub",
    taglineDesc: "Discover the engineering friction, structural missteps, cash burns, and regulatory hurdles that crippled unicorn ideas before they reached security.",
    analyzingNow: "Analyzing worldwide now",
    customAdded: "custom-added",
    capitalBurned: "Capital Burned",
    cumulativeFunding: "Cumulative VC funding",
    blueprintNodes: "Edge Blueprint Nodes",
    copyableSpecs: "Copyable specs",
    blueprintBadge: "💻 Production-Ready Coding Blueprints",
    blueprintCompatibility: "These codebases are directly compatible with Cloudflare Workers (Hono dialect) and Drizzle SQLite/D1 ORM pipelines.",
    seoCheckpoints: "Multi-lingual SEO Checkpoints",
    seoDescription: "Dynamic internationalized sub-directories are served instantly at edge matching hreflangs and canonical parameters.",
    architectLabel: "● Architect:",
    dbTargetLabel: "● DB target:",
    engineLabel: "● Engine:",
    uiThemeLabel: "● UI theme:",
    architectVal: "Elite CTO & SaaS Founder Node",
    dbTargetVal: "Cloudflare D1 (Drizzle Driven)",
    engineVal: "Node.js Express + TSX Proxy",
    uiThemeVal: "Space-Graveyard Twilight",
    footerDesc: "A comprehensive global cataloging of failure lessons, database schemas, and AI diagnostics built for Cloudflare Edge optimization.",
    copyRights: "All rights reserved.",
    customAutopsy: "Custom Autopsy",
    riskFactorsTitle: "Financial Risk & Autopsy Ratio Metrics",
    preciselyWhatWentWrong: "Precisely What Went Wrong (Autopsy Report)",
    funding: "Funding",
    closeReport: "Close Report",
    selectLanguage: "Select Region / Locale"
  },
  fa: {
    title: "PIMXFAIL",
    subtitle: "بزرگترین پایگاه داده استارت‌آپ‌های شکست‌خورده، کالبدشکافی‌ها و درس‌های آموخته‌شده.",
    tagline: "جایی که ایده‌های مرده برای همیشه زنده می‌مانند. از گذشته درس بگیرید تا آینده را بسازید.",
    searchPlaceholder: "جستجو براساس نام، بنیان‌گذار یا کلمه کلیدی...",
    filterAll: "همه حوزه‌ها",
    filterReason: "همه دلایل شکست",
    addBtn: "ثبت گزارش شکست استارت‌آپ",
    analyzing: "در حال تحلیل بردار شکست...",
    analyzeBtn: "کنسول تحلیل شکست هوش مصنوعی",
    blueprintTitle: "مرکز نقشه‌های فنی سیستم",
    blueprintSubtitle: "پیکربندی‌های لبه (Edge) آماده تولید و قابل کپی را بررسی کنید",
    statsTitle: "آمار کالبدشکافی",
    failureByReason: "تفکیک دلایل شکست بر اساس علت ریشه",
    averageLifespan: "جدول زمانی بقا و طول عمر",
    submitSuccess: "کالبدشکافی با موفقیت ثبت شد! در انتظار تایید مدیریت.",
    failureScore: "شاخص شکست",
    marketFit: "تناسب با بازار",
    execution: "کیفیت اجرا",
    fundingRisk: "ریسک تامین مالی",
    competitorRisk: "اشباع رقبا",
    lessonsTitle: "درس‌های آموخته‌شده کالبدشکافی",
    aboutAuthor: "مشخصات فنی معمار ارشد سیستم",
    bookmarkTab: "کالبدشکافی‌های نشانه‌گذاری شده من",
    noBookmarks: "هنوز هیچ کالبدشکافی را ذخیره نکرده‌اید.",
    activeUsers: "کاربر فعال",
    gravesCount: "تعداد گزارش‌های ثبت‌شده شکست",
    reasonsCount: "علل متمایز شناسایی‌شده",
    learnHub: "جزئیات معماری مهندسی پایگاه داده",
    promptName: "نام استارت‌آپ نامزد",
    promptDesc: "شرح کالبدشکافی و مشکلات عملیاتی",
    promptIndustry: "صنعت تجاری عمودی",
    promptReason: "کاتالیزور اصلی فروپاشی",
    promptSubmit: "تولید تشخیص کالبدشکافی لبه",
    diagnosticTitle: "گزارش تشخیص نهایی کالبدشکافی",
    mistakesTitle: "اشتباهات سیستمی اولیه",
    recoveryAction: "سناریوی معکوس بقا و بهبود",
    graveyardDb: "پایگاه داده شکست‌ها",
    blueprintTabsHeader: "بخش‌های نقشه‌های فنی",
    copySpecCode: "کپی کد مشخصات فنی",
    copiedSection: "بخش کپی شد!",
    instantDeath: "مرگ آنی",
    pivotCrisis: "بحران چرخش (Pivot)",
    scalingTrap: "تله مقیاس‌دهی",
    legacyFade: "افول تدریجی",
    range: "دوران",
    medianSurvivalAlert: "میانگین نرخ بقا: ۴.۷ سال قبل از فروپاشی کل نقدینگی. ۸۲٪ از موارد شکست ثبت شده در پایگاه داده ما، قبل از فرسودگی سرمایه ناشی از محرک‌های نامناسب مقیاس‌دهی، یک راند جذب سرمایه سری A انجام داده بودند.",
    breakdownNoMarket: "عدم نیاز بازار (کویبی)",
    breakdownEconomics: "اقتصاد و مدل مالی ناکارآمد (وی‌ورک)",
    breakdownEngineering: "مهندسی بیش از حد پیچیده (جویسرو)",
    breakdownFraud: "کلاهبرداری و مدیریت نامناسب (اف‌تی‌اکس، ترانوس)",
    breakdownSaturation: "اشباع بازار و رقبا (پبل)",
    language: "Farsi",

    hubBadge: "💀 پایگاه داده تخصصی کالبدشکافی استارت‌آپ‌ها",
    taglineDesc: "کالبدشکافی چالش‌های فنی، تصمیمات ساختاری نادرست، هدررفت سرمایه‌ها و موانع قانونی که استارت‌آپ‌های بزرگ را پیش از موفقیت به زانو درآوردند.",
    analyzingNow: "در حال پایش و تحلیل در سراسر جهان",
    customAdded: "ثبت‌شده سفارشی",
    capitalBurned: "سرمایه خارج‌شده/سوخته",
    cumulativeFunding: "مجموع سرمایه خطرپذیر فوت‌شده",
    blueprintNodes: "گره‌های فنی نقشه سیستم",
    copyableSpecs: "مشخصات فنی و کدهای کپی",
    blueprintBadge: "💻 نقشه‌های فنی آماده تولید",
    blueprintCompatibility: "این پایگاه‌های کد مستقیماً با کلاودفلر ورکرز (Hono) و خط لوله دریزل SQLite/D1 سازگار هستند.",
    seoCheckpoints: "نقاط بررسی سئو چندزبانه",
    seoDescription: "دایرکتوری‌های فرعی بین‌المللی پویا بلافاصله در لبه (Edge) مطابق با پارامترهای hreflang و هنجاری سرویس‌دهی می‌شوند.",
    architectLabel: "● معمار سیستم:",
    dbTargetLabel: "● پایگاه داده هدف:",
    engineLabel: "● موتور اصلی:",
    uiThemeLabel: "● پوسته رابط کاربری:",
    architectVal: "گره نخبه معمار CTO و بنیان‌گذار ساس",
    dbTargetVal: "کلاودفلر D1 (هدایت‌شده با Drizzle)",
    engineVal: "اکسپرس Node.js + پروکسی TSX",
    uiThemeVal: "گرگ‌ومیش آخرالزمانی کهکشان",
    footerDesc: "فهرست جامع جهانی از درس‌های شکست، طرح‌های پایگاه داده و ابزارهای تشخیص هوش مصنوعی برای بهینه‌سازی لبه کلاودفلر.",
    copyRights: "تمامی حقوق محفوظ است.",
    customAutopsy: "کالبدشکافی سفارشی",
    riskFactorsTitle: "نسبت شاخص‌های ریسک مالی و کالبدشکافی",
    preciselyWhatWentWrong: "دلیل شکست و کالبدشکافی مالی عملیاتی",
    funding: "سرمایه جذب‌شده",
    closeReport: "بستن گزارش",
    selectLanguage: "انتخاب زبان"
  },
  de: {
    title: "PIMXFAIL",
    subtitle: "Die weltweit größte Datenbank für gescheiterte Startups, Post-Mortems und Lehren.",
    tagline: "Wo gescheiterte Ideen ewig leben. Lerne von den Toten, um die Zukunft zu bauen.",
    searchPlaceholder: "Suche nach Startup, Gründer oder Keyword...",
    filterAll: "Alle Branchen",
    filterReason: "Alle Fehlerursachen",
    addBtn: "Autopsie einreichen",
    analyzing: "Analysiere Fehlervektor...",
    analyzeBtn: "KI-Ausfall-Analysenkonsole",
    blueprintTitle: "Technische Blaupausen",
    blueprintSubtitle: "Entdecke kopierbare Edge-Konfigurationen für diese App",
    statsTitle: "Autopsy-Statistiken",
    failureByReason: "Fehleraufteilung nach Ursachen",
    averageLifespan: "Überlebens-Timeline",
    submitSuccess: "Autopsie erfolgreich eingereicht! Waret auf Moderation.",
    failureScore: "Fehler-Score",
    marketFit: "Marktanpassung",
    execution: "Ausführung",
    fundingRisk: "Finanzierungsrisiko",
    competitorRisk: "Wettbewerber-Sättigung",
    lessonsTitle: "Gelernt Lektionen",
    aboutAuthor: "Elite-CTO-Architekturknoten",
    bookmarkTab: "Meine Lesezeichen",
    noBookmarks: "Du hast noch keine Autopsien gespeichert.",
    activeUsers: "Aktive Analysten",
    gravesCount: "Startup-Autopsien",
    reasonsCount: "Fehlerkatalysatoren",
    learnHub: "Technische Spezifikationen",
    promptName: "Startup-Anwärter",
    promptDesc: "Autopsiebeschreibung & betriebliche Reibung",
    promptIndustry: "Branchenzweig",
    promptReason: "Hauptgrund des Zusammenbruchs",
    promptSubmit: "Autopsie-Diagnose erstellen",
    diagnosticTitle: "Autopsie-Diagnosebericht",
    mistakesTitle: "Systematische Hauptfehler",
    recoveryAction: "Soll-Szenario zur Rettung",
    graveyardDb: "Friedhof DB",
    blueprintTabsHeader: "Blaupausen-Bereiche",
    copySpecCode: "Spezifikationscode kopieren",
    copiedSection: "Bereich kopiert!",
    instantDeath: "Sofortiger Tod",
    pivotCrisis: "Pivot-Krise",
    scalingTrap: "Skalierungsfalle",
    legacyFade: "Langsamer Verfall",
    range: "Zeitraum",
    medianSurvivalAlert: "Mittlere Überlebensrate: 4,7 Jahre vor dem Zusammenbruch der Liquiditätsreserven. 82% der untersuchten gescheiterten Unternehmen in unserer Datenbank haben eine Series-A-Finanzierungsrunde abgeschlossen, bevor sie aufgrund ungeeigneter Skalierungsreize Kapitalerschöpfung erlitten.",
    breakdownNoMarket: "Kein Marktbedarf (Quibi)",
    breakdownEconomics: "Dysfunktionale Wirtschaftlichkeit (WeWork)",
    breakdownEngineering: "Über-Engineering (Juicero)",
    breakdownFraud: "Betrug & Fehlverhalten (FTX, Theranos)",
    breakdownSaturation: "Wettbewerber-Sättigung (Pebble)",
    language: "Deutsch",

    hubBadge: "💀 Globales Autopsie-Datenbank-Hub",
    taglineDesc: "Entdecken Sie technische Reibungen, strukturelle Fehltritte, Cash-Burns und regulatorische Hürden, die Einhorn-Ideen vor der Absicherung zunichtemachten.",
    analyzingNow: "Weltweite Echtzeit-Analyse",
    customAdded: "benutzerdefiniert",
    capitalBurned: "Verbranntes Kapital",
    cumulativeFunding: "Kumuliertes VC-Kapital",
    blueprintNodes: "Edge-Architekturunterlagen",
    copyableSpecs: "Kopierbare Codes",
    blueprintBadge: "💻 Produktionsreife Programmier-Blaupausen",
    blueprintCompatibility: "Diese Code-Libraries sind voll kompatibel mit Cloudflare Workers (Hono-Framework) und Drizzle-SQLite/D1-Datenbanken.",
    seoCheckpoints: "Multilinguale SEO-Prüfpunkte",
    seoDescription: "Dynamische internationalisierte Unterverzeichnisse werden sofort auf Edge-Ebene bereitgestellt, basierend auf Hreflangs und kanonischen Parametern.",
    architectLabel: "● Architekt:",
    dbTargetLabel: "● Datenbank-Target:",
    engineLabel: "● Engine:",
    uiThemeLabel: "● UI-Theme:",
    architectVal: "Elite-CTO & SaaS-Gründerknoten",
    dbTargetVal: "Cloudflare D1 (Unterstützt durch Drizzle)",
    engineVal: "Node.js Express & TSX Proxy",
    uiThemeVal: "Space-Graveyard Dämmerung",
    footerDesc: "Eine umfassende globale Katalogisierung von Misserfolgslektionen, Datenbankschemata und KI-Diagnosen für die Cloudflare Edge-Optimierung.",
    copyRights: "Alle Rechte vorbehalten.",
    customAutopsy: "Benutzerdefinierte Autopsie",
    riskFactorsTitle: "Finanzielle Risikofaktoren & Autopsie-Verhältnis-Metriken",
    preciselyWhatWentWrong: "Was genau schief gelaufen ist (Autopsiebericht)",
    funding: "Finanzierung",
    closeReport: "Bericht schließen",
    selectLanguage: "Region / Sprache wählen"
  },
  zh: {
    title: "PIMXFAIL",
    subtitle: "全球最大的已倒闭创业公司数据库、尸检报告和教训总结。",
    tagline: "失败的创意在这里永生。从死亡中吸取教训，来构建属于你的未来。",
    searchPlaceholder: "输入公司、创始人或关键字进行搜索...",
    filterAll: "所有行业",
    filterReason: "所有失败原因",
    addBtn: "提交创业尸检报告",
    analyzing: "正在分析失败根源...",
    analyzeBtn: "AI 故障分析控制台",
    blueprintTitle: "技术蓝图中心",
    blueprintSubtitle: "在这里探索和复制适用于该应用的高性能 Edge 生产级配置",
    statsTitle: "尸检统计看板",
    failureByReason: "失败根本原因详细拆解",
    averageLifespan: "存活生命周期跨度",
    submitSuccess: "尸检报告提交成功！正等待管理员审核。",
    failureScore: "失败指数",
    marketFit: "市场契合度",
    execution: "执行质量",
    fundingRisk: "资金断档风险",
    competitorRisk: "竞争饱和压力",
    lessonsTitle: "失败血泪教训",
    aboutAuthor: "首席前瞻架构师规范",
    bookmarkTab: "我收藏的失败档案",
    noBookmarks: "您尚未收藏任何尸检报告。",
    activeUsers: "活跃分析师",
    gravesCount: "记录在案尸检",
    reasonsCount: "独立失败因子",
    learnHub: "数据库架构与性能参数",
    promptName: "创业公司名称",
    promptDesc: "尸检背景及核心运营痛点",
    promptIndustry: "商业细分领域",
    promptReason: "导致崩盘的首要致命伤",
    promptSubmit: "一键生成 AI 尸检报告",
    diagnosticTitle: "AI 最终尸检诊断报告",
    mistakesTitle: "系统性核心失误",
    recoveryAction: "挽救生命周期逆转方案",
    graveyardDb: "创业坟墓 DB",
    blueprintTabsHeader: "技术架构章节",
    copySpecCode: "复制规范代码",
    copiedSection: "部分已复制！",
    instantDeath: "即时夭折",
    pivotCrisis: "转型危机",
    scalingTrap: "盲目扩张陷阱",
    legacyFade: "旧部风化流失",
    range: "周期跨度",
    medianSurvivalAlert: "中位生存率：资金链断裂前 4.7 年。我们数据库中记录的 82% 的失败公司，在因缺乏合理的规模拓展条件而耗尽资本之前，曾经成功获得 A 轮融资。",
    breakdownNoMarket: "没有 market 需求 (Quibi)",
    breakdownEconomics: "畸形经济模型 (WeWork)",
    breakdownEngineering: "过度工程设计 (Juicero)",
    breakdownFraud: "欺诈与管理失职 (FTX, Theranos)",
    breakdownSaturation: "竞争饱和压迫 (Pebble)",
    language: "Chinese",

    hubBadge: "💀 全球创业陨落大数据库",
    taglineDesc: "探寻那些在抵达安全线之前就折戟沉沙的独角兽创意背后的技术摩擦、结构性失误、资金空烧以及监管障碍。",
    analyzingNow: "全球实时分析中",
    customAdded: "用户自定义添加",
    capitalBurned: "消耗资本总额",
    cumulativeFunding: "累计风投资金空烧",
    blueprintNodes: "边缘架构模型节点",
    copyableSpecs: "可一键复制规范",
    blueprintBadge: "💻 生产级可用开发蓝图",
    blueprintCompatibility: "这些代码库与 Cloudflare Workers (采用 Hono 框架) 以及 Drizzle SQLite/D1 ORM 流程完美兼容。",
    seoCheckpoints: "多语言 SEO 检查点",
    seoDescription: "动态全球多语言子目录在边缘端即时响应，与 hreflangs 标语和规范参数完美呼应。",
    architectLabel: "● 总设计师:",
    dbTargetLabel: "● 数据存储:",
    engineLabel: "● 核心引擎:",
    uiThemeLabel: "● 界面主题:",
    architectVal: "顶尖 CTO 与 SaaS 联合发起核心",
    dbTargetVal: "Cloudflare D1 (Drizzle ORM 驱动)",
    engineVal: "Node.js Express 与 TSX 代理网关",
    uiThemeVal: "深空之陨永夜幽蓝",
    footerDesc: "由 Cloudflare 全球边缘优化引擎驱动，全面汇集已关闭企业的血泪教训、底层架构表模型及 AI 诊断套件。",
    copyRights: "版权所有，保留所有权利。",
    customAutopsy: "自定义报告",
    riskFactorsTitle: "财务风险与尸检指标分析",
    preciselyWhatWentWrong: "具体折戟原因（诊断书）",
    funding: "融资规模",
    closeReport: "关闭报告",
    selectLanguage: "选择地区/语言"
  },
  es: {
    title: "PIMXFAIL",
    subtitle: "La base de datos de startups fracasadas, autopsias de negocios y lecciones más grande del mundo.",
    tagline: "Donde las ideas que fallaron viven para siempre. Aprende de los caídos para construir el futuro.",
    searchPlaceholder: "Buscar por startup, fundador o palabra clave...",
    filterAll: "Todas las Industrias",
    filterReason: "Todas las Razones",
    addBtn: "Enviar Autopsia",
    analyzing: "Analizando vector de fallo...",
    analyzeBtn: "Consola de Análisis de Fallos por IA",
    blueprintTitle: "Planos Técnicos del Sistema",
    blueprintSubtitle: "Explora configuraciones Cloudflare productivas listas para copiar",
    statsTitle: "Estadísticas de Autopsias",
    failureByReason: "Desglose por causa raíz",
    averageLifespan: "Línea de Tiempo de Supervivencia",
    submitSuccess: "Autopsia enviada con éxito. Esperando aprobación.",
    failureScore: "Puntaje de Fracaso",
    marketFit: "Ajuste de Mercado",
    execution: "Ejecución",
    fundingRisk: "Riesgo de Fondos",
    competitorRisk: "Saturación Competitiva",
    lessonsTitle: "Lecciones Aprendidas de la Autopsia",
    aboutAuthor: "Especificación de Ingeniero Principal",
    bookmarkTab: "Mis Autopsias Guardadas",
    noBookmarks: "No has guardado ninguna autopsia todavía.",
    activeUsers: "Analistas Activos",
    gravesCount: "Autopsias Registradas",
    reasonsCount: "Factores de Fallo Identificados",
    learnHub: "Integridad del esquema de datos",
    promptName: "Nombre de la startup",
    promptDesc: "Descripción de autopsia y retos operativos",
    promptIndustry: "Vertical industrial",
    promptReason: "Catalizador principal del colapso",
    promptSubmit: "Generar Diagnóstico Completo",
    diagnosticTitle: "Informe de Diagnóstico de Autopsia",
    mistakesTitle: "Errores Sitémicos Primarios",
    recoveryAction: "Acción Contrafactual para Salvarla",
    graveyardDb: "Base de Cementerio",
    blueprintTabsHeader: "Secciones Técnicas",
    copySpecCode: "Copiar Código Especificación",
    copiedSection: "¡Sección copiada!",
    instantDeath: "Muerte Instantánea",
    pivotCrisis: "Crisis de Pivote",
    scalingTrap: "Trampa de Escalamiento",
    legacyFade: "Deterioro de Legado",
    range: "ciclo",
    medianSurvivalAlert: "Tasa de supervivencia promedio: 4.7 años antes del colapso de reservas. El 82% de los fracasos registrados en nuestra base de datos obtuvieron financiamiento previo serie A antes de experimentar la bancarrota por escalabilidad equivocada.",
    breakdownNoMarket: "Sin Necesidad de Mercado (Quibi)",
    breakdownEconomics: "Economía Disfuncional (WeWork)",
    breakdownEngineering: "Sobre-ingeniería (Juicero)",
    breakdownFraud: "Fraude y Mala Gobernanza (FTX, Theranos)",
    breakdownSaturation: "Saturación Competitiva (Pebble)",
    language: "Español",

    hubBadge: "💀 Base de Datos de Autopsias Globales",
    taglineDesc: "Descubra las fricciones de ingeniería, errores estructurales, quema de efectivo y obstáculos regulatorios que paralizaron los proyectos unicornio antes de alcanzar la estabilidad.",
    analyzingNow: "Analizando a nivel mundial ahora",
    customAdded: "agregado personalizado",
    capitalBurned: "Capital Quemado",
    cumulativeFunding: "Financiamiento acumulado de VC",
    blueprintNodes: "Nodos de Arquitectura Edge",
    copyableSpecs: "Códigos copiables",
    blueprintBadge: "💻 Arquitecturas de Código Listas Para Producción",
    blueprintCompatibility: "Estas arquitecturas son directamente compatibles con Cloudflare Workers (dialecto Hono) y bases de datos Drizzle SQLite/D1.",
    seoCheckpoints: "Puntos de Control de SEO Multilingüe",
    seoDescription: "Los subdirectorios internacionales dinámicos se implementan directamente en la red de borde con compatibilidad de etiquetas hreflang.",
    architectLabel: "● Arquitecto:",
    dbTargetLabel: "● Base de Datos:",
    engineLabel: "● Motor:",
    uiThemeLabel: "● Tema UI:",
    architectVal: "CTO de Élite y Nodo Fundador de SaaS",
    dbTargetVal: "Cloudflare D1 (Impulsado por Drizzle)",
    engineVal: "Node.js Express + Proxy TSX",
    uiThemeVal: "Crepúsculo de Cementerio Espacial",
    footerDesc: "Un catálogo de fracasos empresariales, esquemas de bases de datos y utilidades de IA optimizadas para Cloudflare Edge.",
    copyRights: "Todos los derechos reservados.",
    customAutopsy: "Autopsia Personalizada",
    riskFactorsTitle: "Métricas de riesgo financiero y análisis de fallas",
    preciselyWhatWentWrong: "Qué salió mal de manera precisa (Informe de autopsia)",
    funding: "Financiamiento",
    closeReport: "Cerrar Informe",
    selectLanguage: "Seleccionar Región / Idioma"
  },
  fr: {
    title: "PIMXFAIL",
    subtitle: "La plus grande base de données de startups en faillite, post-mortems et retours d'expérience.",
    tagline: "Là où les idées mortes vivent éternellement. Apprenez de l'échec pour bâtir l'avenir.",
    searchPlaceholder: "Rechercher par startup, fondateur, mot-clé...",
    filterAll: "Tous les Secteurs",
    filterReason: "Toutes les Causes",
    addBtn: "Soumettre une Autopsie",
    analyzing: "Analyse du vecteur d'échec...",
    analyzeBtn: "Console d'Analyse d'Échec par IA",
    blueprintTitle: "Blueprints Techniques",
    blueprintSubtitle: "Copie des configurations Edge de production optimisées pour Cloudflare",
    statsTitle: "Statistiques d'Échec",
    failureByReason: "Répartition selon la cause",
    averageLifespan: "Chronologie de Survie",
    submitSuccess: "Autopsie soumise avec succès! En attente de moderation.",
    failureScore: "Taux d'Échec",
    marketFit: "Adéquation Marché",
    execution: "Qualité d'Exécution",
    fundingRisk: "Risque de Trésorerie",
    competitorRisk: "Pression Concurrentielle",
    lessonsTitle: "Leçons Tirées des Autopsies",
    aboutAuthor: "Spécification d'Architecture CTO",
    bookmarkTab: "Mes Favoris",
    noBookmarks: "Vous n'avez pas encore de post-mortems en favoris.",
    activeUsers: "Analystes Actifs",
    gravesCount: "Autopsies Archivées",
    reasonsCount: "Facteurs d'Échecs Distincts",
    learnHub: "Directives clés d'infrastructure",
    promptName: "Nom de la startup",
    promptDesc: "Description de l'échec et frictions rencontrées",
    promptIndustry: "Secteur d'activité",
    promptReason: "Déclencheur majeur de l'échec",
    promptSubmit: "Générer le diagnostic d'autopsie",
    diagnosticTitle: "Rapport de Diagnostic d'Échec",
    mistakesTitle: "Erreurs Systémiques Majeures",
    recoveryAction: "Scénario Alternatif de Survie",
    graveyardDb: "Base de Cimetière",
    blueprintTabsHeader: "Sections Techniques",
    copySpecCode: "Copier le Code de Spécification",
    copiedSection: "Section copiée !",
    instantDeath: "Mort Instantanée",
    pivotCrisis: "Crise de Pivot",
    scalingTrap: "Piège de Croissance",
    legacyFade: "Déclin de l'Héritage",
    range: "cycle",
    medianSurvivalAlert: "Taux de survie médian : 4,7 ans avant l'épuisement des liquidités. 82% des échecs répertoriés ont levé une série A avant l'extinction de capital induite par un scaling inadapté.",
    breakdownNoMarket: "Pas de Besoin Marché (Quibi)",
    breakdownEconomics: "Économie Disfonctionnelle (WeWork)",
    breakdownEngineering: "Sur-ingénierie (Juicero)",
    breakdownFraud: "Fraude et Mauvaise Gestion (FTX, Theranos)",
    breakdownSaturation: "Saturation Concurrentielle (Pebble)",
    language: "Français",

    hubBadge: "💀 Hub de Base de Données d'Autopsies Globales",
    taglineDesc: "Découvrez les frictions techniques, les erreurs structurelles, les pertes financières et les obstacles réglementaires qui ont détruit les licornes avant d'atteindre la sécurité.",
    analyzingNow: "Analyse en direct à l'échelle mondiale",
    customAdded: "ajouté sur mesure",
    capitalBurned: "Capital Perdu",
    cumulativeFunding: "Financement cumulé par capital-risque",
    blueprintNodes: "Nœuds d'Architecture Edge",
    copyableSpecs: "Codes copiables",
    blueprintBadge: "💻 Blueprints de Code Prêts pour la Production",
    blueprintCompatibility: "Ces bases de code sont directement compatibles avec Cloudflare Workers (dialecte Hono) et les pipelines Drizzle SQLite/D1 ORM.",
    seoCheckpoints: "Points de Contrôle SEO Multilingues",
    seoDescription: "Les sous-répertoires internationaux dynamiques sont servis instantanément à l'Edge, assortis de balises hreflang et d'URL canoniques.",
    architectLabel: "● Architecte:",
    dbTargetLabel: "● Base de Données:",
    engineLabel: "● Moteur:",
    uiThemeLabel: "● Thème de l'interface:",
    architectVal: "CTO d'Élite & Nœud Fondateur de SaaS",
    dbTargetVal: "Cloudflare D1 (Piloté par Drizzle)",
    engineVal: "Node.js Express + Proxy TSX",
    uiThemeVal: "Crépuscule d'Outre-Tombe Spatial",
    footerDesc: "Un catalogue des échecs de startups, des schémas de base de données et des diagnostics d'IA optimisés pour Cloudflare Edge.",
    copyRights: "Tous droits réservés.",
    customAutopsy: "Autopsie Personnalisée",
    riskFactorsTitle: "Métriques de risque de financement et d'exécution",
    preciselyWhatWentWrong: "Ce qui s'est passé précisément (Rapport d'autopsie)",
    funding: "Financement",
    closeReport: "Fermer le Rapport",
    selectLanguage: "Sélectionner Région / Langue"
  },
  ar: {
    title: "PIMXFAIL",
    subtitle: "أكبر قاعدة بيانات عالمية للشركات الناشئة الفاشلة، عمليات رصد الفشل، والدروس المستفادة.",
    tagline: "حيث تعيش الأفكار الميتة إلى الأبد. تعلم من الماضي لتصنع المستقبل.",
    searchPlaceholder: "ابحث باسم الشركة، المؤسس، الكلمة المفتاحية...",
    filterAll: "جميع القطاعات",
    filterReason: "جميع أسباب الفشل",
    addBtn: "تقديم تقرير الفشل",
    analyzing: "تحليل ناقل الفشل الآن...",
    analyzeBtn: "كونسول تحليل الفشل بالذكاء الاصطناعي",
    blueprintTitle: "مخططات النظام التقنية",
    blueprintSubtitle: "استعرض وانسخ إعدادات الـ Edge الجاهزة للإنتاج لشبكة Cloudflare",
    statsTitle: "إحصائيات عمليات التشريح للفشل",
    failureByReason: "تحليل الفشل حسب الأسباب الجذرية",
    averageLifespan: "المخطط الزمني للبقاء والاستمرارية",
    submitSuccess: "تم تقديم التقرير بنجاح! بانتظار مراجعة الإدارة.",
    failureScore: "مؤشر الفشل",
    marketFit: "الملاءمة مع السوق",
    execution: "جودة التنفيذ",
    fundingRisk: "مخاطر التمويل",
    competitorRisk: "استحواذ المنافسين",
    lessonsTitle: "الدروس المستفادة والنتائج",
    aboutAuthor: "مواصفات مهندس الأنظمة الرائد",
    bookmarkTab: "التقارير المحفوظة تفضيلياً",
    noBookmarks: "لم تقم بحفظ أي تقارير فشل حتى الآن.",
    activeUsers: "محلل نشط",
    gravesCount: "عدد عمليات التشريح",
    reasonsCount: "أسباب الفشل الفريدة المرصودة",
    learnHub: "قواعد بيانات النظام وإدارة التخزين",
    promptName: "اسم الشركة الناشئة",
    promptDesc: "سياق الفشل والتحديات التشغيلية",
    promptIndustry: "القطاع التجاري والنشاط",
    promptReason: "المحفز الرئيسي للانهيار السريع",
    promptSubmit: "توليد التشخيص النهائي للفشل",
    diagnosticTitle: "تقرير تشخيص الفشل الذكي",
    mistakesTitle: "الأخطاء التنظيمية الهيكلية",
    recoveryAction: "الخيار البديل للإنقاذ والتعافي",
    graveyardDb: "قاعدة بيانات الفشل",
    blueprintTabsHeader: "أقسام المخططات",
    copySpecCode: "نسخ كود المواصفات",
    copiedSection: "تم نسخ القسم!",
    instantDeath: "موت فوري",
    pivotCrisis: "أزمة تغيير الاتجاه",
    scalingTrap: "فخ التوسع",
    legacyFade: "تلاشي الإرث",
    range: "فترة",
    medianSurvivalAlert: "متوسط نسبة البقاء والاستمرارية: 4.7 سنوات قبل نفاد الاحتياطي النقدي للشركات. 82% من الشركات الفاشلة المسجلة لدينا نجحت في جلب جولة تمويلية (Series A) قبل حدوث الانهيار المالي بسبب سوء توجيه وتوقيت التوسع.",
    breakdownNoMarket: "عدم وجود حاجة في السوق (كويبي)",
    breakdownEconomics: "نموذج اقتصادي غير مجدٍ (وي وورك)",
    breakdownEngineering: "الهندسة المفرطة والتعقيد (جوسيرو)",
    breakdownFraud: "الاحتيال وسوء الإدارة (FTX، ثيرانوس)",
    breakdownSaturation: "تشبع السوق والمنافسة الشديدة (بيبل)",
    language: "العربية",

    hubBadge: "💀 المركز العالمي لتشريح فشل المشاريع",
    taglineDesc: "اكتشف الفجوات الهندسية، القرارات الهيكلية الخاطئة، استنزاف الأموال، والعقبات التنظيمية التي أطاحت بالأفكار الواعدة قبل أن تصل إلى الأمان التمويلي.",
    analyzingNow: "تحليل مستمر على نطاق عالمي الآن",
    customAdded: "مضاف بشكل مخصص",
    capitalBurned: "رأس المال المستنزف",
    cumulativeFunding: "إجمالي تمويل رأس المال المغامر المستنزف",
    blueprintNodes: "مخططات وهياكل النظام الرائدة",
    copyableSpecs: "مواصفات قابلة للنسخ المباشر",
    blueprintBadge: "💻 مخططات برمجية جاهزة للبيئة الفعلية",
    blueprintCompatibility: "هذه قواعد البرمجة متوافقة مباشرة مع بيئة عمل Cloudflare Workers (إطار Hono) ومحرك قواعد بيانات Drizzle SQLite/D1.",
    seoCheckpoints: "نقاط فحص السيو متعدد اللغات",
    seoDescription: "يتم تخديم المجلدات الفرعية الدولية الديناميكية فوراً من خوادم الـ Edge بأسلوب يتطابق مع معايير hreflang والروابط الأساسية.",
    architectLabel: "● مهندس النظام:",
    dbTargetLabel: "● قاعدة البيانات:",
    engineLabel: "● محرك التشغيل:" ,
    uiThemeLabel: "● المظهر المرئي:",
    architectVal: "المدير التقني الرائد والمنشئ لمنصات الساس",
    dbTargetVal: "سحابة Cloudflare D1 (المدارة بـ Drizzle)",
    engineVal: "بيئة Node.js Express مع وسيط TSX",
    uiThemeVal: "سمات الفضاء وظلمة الانهيار الفلكية",
    footerDesc: "كتالوج عالمي شامل لتوثيق أسباب الفشل، مخططات قواعد البيانات، وتقارير التشخيص بالذكاء الاصطناعي مهيأة لتقنيات Cloudflare Edge.",
    copyRights: "جميع الحقوق محفوظة.",
    customAutopsy: "تقرير مخصص",
    riskFactorsTitle: "مقاييس المخاطر المالية ونسب تشريح الانهيار",
    preciselyWhatWentWrong: "تفاصيل الانهيار الحقيقي (تقرير التشريح)",
    funding: "التمويل",
    closeReport: "إغلاق التقرير",
    selectLanguage: "اختر اللغة / المنطقة"
  },
  it: {
    title: "PIMXFAIL",
    subtitle: "Il database di startup fallite, post-mortem e lezioni più grande del mondo.",
    tagline: "Dove le idee che hanno fallito vivono per sempre. Impara dai caduti per costruire il futuro.",
    searchPlaceholder: "Cerca per startup, fondatore o parola chiave...",
    filterAll: "Tutti i Settori",
    filterReason: "Tutti i Motivi",
    addBtn: "Invia Autopsia",
    analyzing: "Analisi del vettore di fallimento...",
    analyzeBtn: "Console Analisi Fallimenti IA",
    blueprintTitle: "Specifiche Tecniche",
    blueprintSubtitle: "Esplora configurazioni Edge pronte per la produzione di Cloudflare",
    statsTitle: "Statistiche Autopsie",
    failureByReason: "Analisi per causa principale",
    averageLifespan: "Timeline di Sopravvivenza",
    submitSuccess: "Autopsia inviata con successo! In attesa di moderazione.",
    failureScore: "Indice di Fallimento",
    marketFit: "Adattamento al Mercato",
    execution: "Qualità di Esecuzione",
    fundingRisk: "Rischio Liquidità",
    competitorRisk: "Saturazione Concorrenti",
    lessonsTitle: "Lezioni Chiauve Apprese",
    aboutAuthor: "Profilo Tecnico CTO",
    bookmarkTab: "Le Mie Autopsie Salvate",
    noBookmarks: "Non hai salvato ancora nessuna autopsia.",
    activeUsers: "Analisti Attivi",
    gravesCount: "Autopsie Registrate",
    reasonsCount: "Fattori di Fallimento Identificati",
    learnHub: "Principi del database",
    promptName: "Nome della startup",
    promptDesc: "Descrizione dell'autopsia e attriti operativi",
    promptIndustry: "Settore industriale",
    promptReason: "Catalizzatore principale del crollo",
    promptSubmit: "Genera Diagnostica Completa",
    diagnosticTitle: "Rapporto di Diagnostica Autopsia",
    mistakesTitle: "Errori Sistemici Primari",
    recoveryAction: "Azione Alternativa Salva-azienda",
    graveyardDb: "Database Cimitero",
    blueprintTabsHeader: "Sezioni di Progetto",
    copySpecCode: "Copia Codice Spec",
    copiedSection: "Sezione Copiata!",
    instantDeath: "Morte Istantanea",
    pivotCrisis: "Crisi di Pivot",
    scalingTrap: "Trappola della Scalabilità",
    legacyFade: "Declino Graduale",
    range: "intervallo",
    medianSurvivalAlert: "Tasso di sopravvivenza mediano: 4,7 anni prima del colapso delle riserve di cassa. L'82% dei fallimenti tracciati ha sollevato investimenti Series A prima di esaurire il capitale a causa di un'espansione errata.",
    breakdownNoMarket: "Nessun Bisogno di Mercato (Quibi)",
    breakdownEconomics: "Modello Economico Disfunzionale (WeWork)",
    breakdownEngineering: "Sovra-ingegnerizzazione (Juicero)",
    breakdownFraud: "Frode e Mala Gestione (FTX, Theranos)",
    breakdownSaturation: "Saturazione di Mercato (Pebble)",
    language: "Italiano",

    hubBadge: "💀 Hub Database Autopsie Globali",
    taglineDesc: "Scopri gli attriti ingegneristici, i passi falsi strutturali, il consumo di cassa e gli ostacoli normativi che hanno stroncato le idee unicorno prima di raggiungere la stabilità.",
    analyzingNow: "Analisi globale attiva in tempo reale",
    customAdded: "aggiunto come personalizzato",
    capitalBurned: "Capitale Bruciato",
    cumulativeFunding: "Finanziamenti totali di capital-risk persi",
    blueprintNodes: "Nodi di Architettura Edge",
    copyableSpecs: "Specifiche copiabili",
    blueprintBadge: "💻 Modelli di Codice Pronti per la Nuova Produzione",
    blueprintCompatibility: "Queste librerie di codice sono compatibili con Cloudflare Workers (dialetto Hono) e database Drizzle SQLite/D1.",
    seoCheckpoints: "Punti di Controllo SEO Multilingue",
    seoDescription: "Le sottocartelle internazionali dinamiche sono servite all'Edge in base a tag hreflang e canonical.",
    architectLabel: "● Architetto:",
    dbTargetLabel: "● Database target:",
    engineLabel: "● Motore:",
    uiThemeLabel: "● Tema dell'interfaccia:",
    architectVal: "CTO d'Elite & Nodo Fondatore SaaS",
    dbTargetVal: "Cloudflare D1 (Guidato da Drizzle)",
    engineVal: "Node.js Express + TSX Proxy",
    uiThemeVal: "Crepuscolo del Cimitero Spaziale",
    footerDesc: "Un catalogo completo delle lezioni di fallimento, schemi di database e diagnostica di intelligenza artificiale per l'ottimizzazione Cloudflare Edge.",
    copyRights: "Tutti i diritti riservati.",
    customAutopsy: "Autopsia Personalizzata",
    riskFactorsTitle: "Indicatori di rischio economico e parametri di fallimento",
    preciselyWhatWentWrong: "Cosa è andato storto esattamente (Rapporto autoptico)",
    funding: "Finanziamenti",
    closeReport: "Chiudi Rapporto",
    selectLanguage: "Seleziona Regione / Lingua"
  },
  ru: {
    title: "PIMXFAIL",
    subtitle: "Крупнейшая база данных закрывшихся стартапов, отчетов о провалах и извлеченных уроков.",
    tagline: "Где неудавшиеся идеи обретают бессмертие. Учись на чужих ошибках для построения будущего.",
    searchPlaceholder: "Поиск по стартапам, учредителям или ключевым словам...",
    filterAll: "Все Отрасли",
    filterReason: "Все Причины Крах",
    addBtn: "Отправить Отчет о Провале",
    analyzing: "Анализ вектора сбоя...",
    analyzeBtn: "Сенсорная консоль анализа провалов ИИ",
    blueprintTitle: "Технические Чертежи",
    blueprintSubtitle: "Исследуйте готовые к копированию Edge конфигурации для Cloudflare",
    statsTitle: "Статистика Вскрытий",
    failureByReason: "Разбивка причин краха",
    averageLifespan: "Хронология Выживаемости",
    submitSuccess: "Отчет успешно отправлен! Ожидает модерации.",
    failureScore: "Индекс Провала",
    marketFit: "Соответствие Рынку",
    execution: "Качество Исполнения",
    fundingRisk: "Риск Финансирования",
    competitorRisk: "Давление Конкурентов",
    lessonsTitle: "Главные Извлеченные Уроки",
    aboutAuthor: "Спецификация Ведущего Архитектора",
    bookmarkTab: "Мои Закладки",
    noBookmarks: "Вы пока не отметили ни одного отчета.",
    activeUsers: "Активных Аналитиков",
    gravesCount: "Архивированных Отчетов",
    reasonsCount: "Выявленных Причин Сбоя",
    learnHub: "Консистентность структуры данных",
    promptName: "Название стартапа",
    promptDesc: "Описание сбоев и трения с клиентами",
    promptIndustry: "Промышленный вертикал",
    promptReason: "Главный катализатор закрытия",
    promptSubmit: "Сгенерировать полный диагноз",
    diagnosticTitle: "Итоговый Аналитический Диагноз ИИ",
    mistakesTitle: "Первичные Системные Ошибки",
    recoveryAction: "Корректирующее Альтернативное Действие",
    graveyardDb: "База Кладбища Крах",
    blueprintTabsHeader: "Разделы Чертежей",
    copySpecCode: "Копировать Код Спецификации",
    copiedSection: "Раздел скопирован!",
    instantDeath: "Мгновенная смерть",
    pivotCrisis: "Кризис поворота",
    scalingTrap: "Ловушка масштабирования",
    legacyFade: "Закат наследия",
    range: "период",
    medianSurvivalAlert: "Медианная выживаемость: 4,7 года до истощения резервов. 82% закрывшихся компаний привлекли раунд Series A перед катастрофой из-за пагубной политики неподдерживаемого расширения.",
    breakdownNoMarket: "Отсутствие рыночного спроса (Quibi)",
    breakdownEconomics: "Проблемы с монетизацией (WeWork)",
    breakdownEngineering: "Избыточное усложнение (Juicero)",
    breakdownFraud: "Мошенничество и халатность (FTX, Theranos)",
    breakdownSaturation: "Жесткое выдавливание конкурентами (Pebble)",
    language: "Русский",

    hubBadge: "💀 Глобальный центр автопсии стартапов",
    taglineDesc: "Узнайте об инженерных проблемах, структурных ошибках, сжигании капитала и регуляторных барьерах, которые погубили многообещающие идеи до их масштабирования.",
    analyzingNow: "Анализируется по всему миру в реальном времени",
    customAdded: "добавлено пользователем",
    capitalBurned: "Сожженный Капитал",
    cumulativeFunding: "Суммарный объем венчурного капитала",
    blueprintNodes: "Архитектурные узлы Edge",
    copyableSpecs: "Спецификации для копирования",
    blueprintBadge: "💻 Готовые к продакшену шаблоны кода",
    blueprintCompatibility: "Эти базы кода напрямую совместимы с Cloudflare Workers (фреймворк Hono) и Drizzle SQLite/D1 ORM.",
    seoCheckpoints: "Многоязычные контрольные точки SEO",
    seoDescription: "Динамические международные подкаталоги мгновенно обслуживаются на стороне Edge, сопоставляя hreflang и канонические параметры.",
    architectLabel: "● Архитектор:",
    dbTargetLabel: "● База данных:",
    engineLabel: "● Движок:",
    uiThemeLabel: "● Тема интерфейса:",
    architectVal: "Узел ведущего CTO и основателя SaaS",
    dbTargetVal: "Cloudflare D1 (на базе Drizzle)",
    engineVal: "Node.js Express + Прокси TSX",
    uiThemeVal: "Сумерки космического погоста",
    footerDesc: "Полный каталог извлеченных уроков, схем баз данных и ИИ-диагностики, разработанный для оптимизации на базе Cloudflare Edge.",
    copyRights: "Все права защищены.",
    customAutopsy: "Пользовательский отчет",
    riskFactorsTitle: "Финансовые риски и метрики детального вскрытия стартапа",
    preciselyWhatWentWrong: "Что именно пошло не так (Аналитический отчет)",
    funding: "Венчурные фонды",
    closeReport: "Закрыть Отчет",
    selectLanguage: "Выбрать регион и язык"
  },
  tr: {
    title: "PIMXFAIL",
    subtitle: "Başarısız girişimlerin, kapanma post-mortem yazılarının ve çıkarılan derslerin en büyük veri tabanı.",
    tagline: "Başarısız fikirlerin sonsuza dek yaşadığı yer. Geleceği inşa etmek için geçmişin kayıplarından öğren.",
    searchPlaceholder: "Girişim adı, kurucu veya anahtar kelime ile ara...",
    filterAll: "Tüm Sektörler",
    filterReason: "Tüm Başarısızlık Nedenleri",
    addBtn: "Kayıp Raporu Gönder",
    analyzing: "Başarısızlık faktörü analiz ediliyor...",
    analyzeBtn: "Yapay Zeka Başarısızlık Konsolu",
    blueprintTitle: "Teknik Mimari Planlar",
    blueprintSubtitle: "Bu uygulama için kopyalanabilir gerçek Cloudflare Edge ayarlarını keşfet",
    statsTitle: "Kayıp İstatistikleri",
    failureByReason: "Kök Neden Başarısızlık Dağılımı",
    averageLifespan: "Girişim Hayatta Kalma Süresi",
    submitSuccess: "Rapor başarıyla gönderildi! Moderatör onayı bekleniyor.",
    failureScore: "Başarısızlık Puanı",
    marketFit: "Pazar Uyumu",
    execution: "Uygulama Kalitesi",
    fundingRisk: "Finansal Risk",
    competitorRisk: "Rakip Satürasyonu",
    lessonsTitle: "Kritik Çıkarılan Dersler",
    aboutAuthor: "Baş Teknik Sorumlu (CTO) Şablonu",
    bookmarkTab: "Yer İşaretlerim",
    noBookmarks: "Henüz bir autopsi yer işaretlerine eklemediniz.",
    activeUsers: "Aktif Analizci",
    gravesCount: "Kayıtlı Autopsi",
    reasonsCount: "Farklı Başarısızlık Faktörü",
    learnHub: "Veritabanı dökümleri ve ilişkiler",
    promptName: "Girişim Adayı",
    promptDesc: "Autopsi detayları ve operasyonel aksaklıklar",
    promptIndustry: "Sektörel dikey",
    promptReason: "Çöküşü başlatan birincil etken",
    promptSubmit: "Kayıp Teşhisi Oluştur",
    diagnosticTitle: "Yapay Zeka Autopsi Teşhis Raporu",
    mistakesTitle: "Temel Sistemsel Hatalar",
    recoveryAction: "Şirketi Kurtaracak Alternatif Hamle",
    graveyardDb: "Kabristan Veritabanı",
    blueprintTabsHeader: "Mimari Şablon Detayları",
    copySpecCode: "Ayar Kodunu Kopyala",
    copiedSection: "Bölüm Kopyalandı!",
    instantDeath: "Anında Ölüm",
    pivotCrisis: "Pivot Krizi",
    scalingTrap: "Ölçekleme Tuzağı",
    legacyFade: "Yavaş Sönüş",
    range: "süreç",
    medianSurvivalAlert: "Ortalama hayatta kalma süresi: Rezervler erimeden önce 4.7 yıl. Veritabanımızda izlenen başarısızlıkların %82'si, zamansız büyüme adımları nedeniyle nakit tükenmeden önce bir Series A yatırım turu kapatabilmişti.",
    breakdownNoMarket: "Pazar Talebi Yok (Quibi)",
    breakdownEconomics: "Bozuk Gelir-Gider Modeli (WeWork)",
    breakdownEngineering: "Aşırı Mühendislik (Juicero)",
    breakdownFraud: "Sahtekarlık ve Kötü Yönetim (FTX, Theranos)",
    breakdownSaturation: "Yoğun Rekabet Sıkışması (Pebble)",
    language: "Türkçe",

    hubBadge: "💀 Küresel Otopsi Veritabanı Merkezi",
    taglineDesc: "Tek boynuzlu at (unicorn) fikirlerini güvenlik sınırına ulaşamadan çökerten teknik sürtüşmeleri, yapısal hataları, nakit yakımlarını ve yasal engelleri keşfedin.",
    analyzingNow: "Küresel olarak gerçek zamanlı analiz ediliyor",
    customAdded: "özel eklenen",
    capitalBurned: "Yakılan Sermaye",
    cumulativeFunding: "Kümülatif VC yatırımı",
    blueprintNodes: "Edge Planlama Düğümleri",
    copyableSpecs: "Kopyalanabilir detaylar",
    blueprintBadge: "💻 Üretime Hazır Kodlama Planları",
    blueprintCompatibility: "Bu kod tabanları Cloudflare Workers (Hono kütüphanesi) ve Drizzle SQLite/D1 ORM veritabanları ile doğrudan uyumludur.",
    seoCheckpoints: "Çok Dilli SEO Kontrol Noktaları",
    seoDescription: "Dinamik uluslararası alt dizinler, hreflang ve standart parametrelerle eşleşecek şekilde edge üzerinde anında sunulur.",
    architectLabel: "● Başmimar:",
    dbTargetLabel: "● Hedef Veritabanı:",
    engineLabel: "● Çekirdek:",
    uiThemeLabel: "● Arayüz Teması:",
    architectVal: "Seçkin CTO ve SaaS Kurucu Düğümü",
    dbTargetVal: "Cloudflare D1 (Drizzle Odaklı)",
    engineVal: "Node.js Express + TSX Vekil Sunucusu",
    uiThemeVal: "Uzay Mezarlığı Alacakaranlığı",
    footerDesc: "Cloudflare Edge optimizasyonu için derlenmiş, başarısızlık derslerinin, veritabanı şemalarının ve yapay zeka otopsi analizlerinin kapsamlı küresel veri tabanı.",
    copyRights: "Tüm hakları saklıdır.",
    customAutopsy: "Özel Otopsi",
    riskFactorsTitle: "Mali risk faktörleri ve otopsi oran değerleri",
    preciselyWhatWentWrong: "Tam Olarak Ne Yanlış Gitti (Otopsi Raporu)",
    funding: "Alınan Yatırım",
    closeReport: "Raporu Kapat",
    selectLanguage: "Bölge / Dil Seç"
  }
};
